import { createClient } from "@supabase/supabase-js"

const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL!
const supabaseAnonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!

export const supabase = createClient(supabaseUrl, supabaseAnonKey)

// Database types
export interface Product {
  id: string
  name: string
  sku: string
  description?: string
  category_id?: string
  price: number
  cost: number
  min_stock: number
  created_at: string
  updated_at: string
  category?: Category
  inventory?: Inventory[]
}

export interface Category {
  id: string
  name: string
  description?: string
  created_at: string
  updated_at: string
}

export interface Warehouse {
  id: string
  name: string
  location: string
  manager: string
  capacity: number
  occupied: number
  status: string
  created_at: string
  updated_at: string
}

export interface Inventory {
  id: string
  product_id: string
  warehouse_id: string
  quantity: number
  reserved_quantity: number
  created_at: string
  updated_at: string
  product?: Product
  warehouse?: Warehouse
}

export interface Customer {
  id: string
  name: string
  email?: string
  phone?: string
  address?: string
  city?: string
  state?: string
  zip_code?: string
  country?: string
  created_at: string
  updated_at: string
}

export interface Order {
  id: string
  order_number: string
  customer_id?: string
  status: string
  priority: string
  subtotal: number
  tax_amount: number
  total_amount: number
  order_date: string
  shipped_date?: string
  delivered_date?: string
  notes?: string
  created_at: string
  updated_at: string
  customer?: Customer
  order_items?: OrderItem[]
}

export interface OrderItem {
  id: string
  order_id: string
  product_id: string
  quantity: number
  unit_price: number
  total_price: number
  created_at: string
  product?: Product
}

export interface StockMovement {
  id: string
  product_id: string
  warehouse_id: string
  movement_type: string
  quantity: number
  reference_type?: string
  reference_id?: string
  notes?: string
  created_at: string
  product?: Product
  warehouse?: Warehouse
}
