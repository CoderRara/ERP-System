import { supabase } from "./supabase"
import type { Product, Category } from "./supabase"

export interface CreateProductData {
  name: string
  description?: string
  sku: string
  category_id?: string
  price: number
  cost: number
  min_stock: number
}

export interface UpdateProductData extends Partial<CreateProductData> {
  id: string
}

export interface StockAdjustment {
  product_id: string
  warehouse_id: string
  quantity: number
  adjustment_type: "increase" | "decrease" | "set"
  reason?: string
}

// Product CRUD operations
export async function getProducts() {
  const { data, error } = await supabase
    .from("products")
    .select(`
      *,
      category:categories(*),
      inventory:inventory(
        *,
        warehouse:warehouses(*)
      )
    `)
    .order("created_at", { ascending: false })

  if (error) throw error
  return data as Product[]
}

export async function getProduct(id: string) {
  const { data, error } = await supabase
    .from("products")
    .select(`
      *,
      category:categories(*),
      inventory:inventory(
        *,
        warehouse:warehouses(*)
      )
    `)
    .eq("id", id)
    .single()

  if (error) throw error
  return data as Product
}

export async function createProduct(productData: CreateProductData) {
  const { data, error } = await supabase.from("products").insert([productData]).select().single()

  if (error) throw error
  return data as Product
}

export async function updateProduct(productData: UpdateProductData) {
  const { id, ...updateData } = productData
  const { data, error } = await supabase.from("products").update(updateData).eq("id", id).select().single()

  if (error) throw error
  return data as Product
}

export async function deleteProduct(id: string) {
  const { error } = await supabase.from("products").delete().eq("id", id)

  if (error) throw error
}

// Category operations
export async function getCategories() {
  const { data, error } = await supabase.from("categories").select("*").order("name")

  if (error) throw error
  return data as Category[]
}

// Inventory operations
export async function adjustStock(adjustment: StockAdjustment) {
  const { data: inventory, error: inventoryError } = await supabase
    .from("inventory")
    .select("quantity")
    .eq("product_id", adjustment.product_id)
    .eq("warehouse_id", adjustment.warehouse_id)
    .single()

  if (inventoryError && inventoryError.code !== "PGRST116") {
    throw inventoryError
  }

  let newQuantity: number
  if (!inventory) {
    // Create new inventory record
    newQuantity =
      adjustment.adjustment_type === "set"
        ? adjustment.quantity
        : adjustment.adjustment_type === "increase"
          ? adjustment.quantity
          : 0
  } else {
    // Update existing inventory
    switch (adjustment.adjustment_type) {
      case "increase":
        newQuantity = inventory.quantity + adjustment.quantity
        break
      case "decrease":
        newQuantity = Math.max(0, inventory.quantity - adjustment.quantity)
        break
      case "set":
        newQuantity = adjustment.quantity
        break
      default:
        throw new Error("Invalid adjustment type")
    }
  }

  // Upsert inventory record
  const { data, error } = await supabase
    .from("inventory")
    .upsert({
      product_id: adjustment.product_id,
      warehouse_id: adjustment.warehouse_id,
      quantity: newQuantity,
      reserved_quantity: 0,
    })
    .select()
    .single()

  if (error) throw error

  // Create stock movement record
  const { error: movementError } = await supabase.from("stock_movements").insert({
    product_id: adjustment.product_id,
    warehouse_id: adjustment.warehouse_id,
    movement_type: adjustment.adjustment_type,
    quantity: adjustment.quantity,
    reference_type: "manual_adjustment",
    notes: adjustment.reason,
  })

  if (movementError) throw movementError

  return data
}

export async function getWarehouses() {
  const { data, error } = await supabase.from("warehouses").select("*").order("name")

  if (error) throw error
  return data
}
