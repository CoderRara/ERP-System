// Local storage utilities for product management
export interface LocalProduct {
  id: string
  name: string
  description?: string
  sku: string
  category: string
  price: number
  cost: number
  min_stock: number
  stock: number
  warehouse: string
  created_at: string
  updated_at: string
}

export interface StockMovement {
  id: string
  product_id: string
  type: "increase" | "decrease" | "set"
  quantity: number
  previous_stock: number
  new_stock: number
  reason?: string
  warehouse: string
  created_at: string
}

const PRODUCTS_KEY = "erp_products"
const STOCK_MOVEMENTS_KEY = "erp_stock_movements"
const CATEGORIES_KEY = "erp_categories"
const WAREHOUSES_KEY = "erp_warehouses"

// Initialize default data
const defaultCategories = ["Electronics", "Furniture", "Accessories", "Components", "Software", "Office Supplies"]

const defaultWarehouses = ["Main Warehouse", "Warehouse B", "Warehouse C", "Distribution Center"]

const defaultProducts: LocalProduct[] = [
  {
    id: "1",
    name: "Wireless Bluetooth Headphones",
    description: "High-quality wireless headphones with noise cancellation",
    sku: "WBH-2024-001",
    category: "Electronics",
    price: 89.99,
    cost: 45.0,
    min_stock: 20,
    stock: 145,
    warehouse: "Main Warehouse",
    created_at: "2024-01-01T00:00:00Z",
    updated_at: "2024-01-01T00:00:00Z",
  },
  {
    id: "2",
    name: "Ergonomic Office Chair",
    description: "Comfortable office chair with lumbar support",
    sku: "EOC-2024-002",
    category: "Furniture",
    price: 299.99,
    cost: 150.0,
    min_stock: 15,
    stock: 8,
    warehouse: "Warehouse B",
    created_at: "2024-01-01T00:00:00Z",
    updated_at: "2024-01-01T00:00:00Z",
  },
  {
    id: "3",
    name: "USB-C Charging Cable",
    description: "Fast charging USB-C cable 6ft length",
    sku: "UCC-2024-003",
    category: "Accessories",
    price: 19.99,
    cost: 8.0,
    min_stock: 50,
    stock: 0,
    warehouse: "Main Warehouse",
    created_at: "2024-01-01T00:00:00Z",
    updated_at: "2024-01-01T00:00:00Z",
  },
]

// Initialize data if not exists
export function initializeData() {
  if (!localStorage.getItem(CATEGORIES_KEY)) {
    localStorage.setItem(CATEGORIES_KEY, JSON.stringify(defaultCategories))
  }
  if (!localStorage.getItem(WAREHOUSES_KEY)) {
    localStorage.setItem(WAREHOUSES_KEY, JSON.stringify(defaultWarehouses))
  }
  if (!localStorage.getItem(PRODUCTS_KEY)) {
    localStorage.setItem(PRODUCTS_KEY, JSON.stringify(defaultProducts))
  }
  if (!localStorage.getItem(STOCK_MOVEMENTS_KEY)) {
    localStorage.setItem(STOCK_MOVEMENTS_KEY, JSON.stringify([]))
  }
}

// Product operations
export function getProducts(): LocalProduct[] {
  const products = localStorage.getItem(PRODUCTS_KEY)
  return products ? JSON.parse(products) : []
}

export function getProduct(id: string): LocalProduct | null {
  const products = getProducts()
  return products.find((p) => p.id === id) || null
}

export function createProduct(productData: Omit<LocalProduct, "id" | "created_at" | "updated_at">): LocalProduct {
  const products = getProducts()
  const newProduct: LocalProduct = {
    ...productData,
    id: Date.now().toString(),
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString(),
  }
  products.push(newProduct)
  localStorage.setItem(PRODUCTS_KEY, JSON.stringify(products))
  return newProduct
}

export function updateProduct(id: string, productData: Partial<LocalProduct>): LocalProduct | null {
  const products = getProducts()
  const index = products.findIndex((p) => p.id === id)
  if (index === -1) return null

  products[index] = {
    ...products[index],
    ...productData,
    updated_at: new Date().toISOString(),
  }
  localStorage.setItem(PRODUCTS_KEY, JSON.stringify(products))
  return products[index]
}

export function deleteProduct(id: string): boolean {
  const products = getProducts()
  const filteredProducts = products.filter((p) => p.id !== id)
  if (filteredProducts.length === products.length) return false

  localStorage.setItem(PRODUCTS_KEY, JSON.stringify(filteredProducts))
  return true
}

// Stock operations
export function adjustStock(
  productId: string,
  adjustment: {
    type: "increase" | "decrease" | "set"
    quantity: number
    reason?: string
    warehouse?: string
  },
): boolean {
  const products = getProducts()
  const productIndex = products.findIndex((p) => p.id === productId)
  if (productIndex === -1) return false

  const product = products[productIndex]
  const previousStock = product.stock
  let newStock: number

  switch (adjustment.type) {
    case "increase":
      newStock = previousStock + adjustment.quantity
      break
    case "decrease":
      newStock = Math.max(0, previousStock - adjustment.quantity)
      break
    case "set":
      newStock = adjustment.quantity
      break
    default:
      return false
  }

  // Update product stock
  products[productIndex].stock = newStock
  products[productIndex].updated_at = new Date().toISOString()
  localStorage.setItem(PRODUCTS_KEY, JSON.stringify(products))

  // Record stock movement
  const movements = getStockMovements()
  const movement: StockMovement = {
    id: Date.now().toString(),
    product_id: productId,
    type: adjustment.type,
    quantity: adjustment.quantity,
    previous_stock: previousStock,
    new_stock: newStock,
    reason: adjustment.reason,
    warehouse: adjustment.warehouse || product.warehouse,
    created_at: new Date().toISOString(),
  }
  movements.push(movement)
  localStorage.setItem(STOCK_MOVEMENTS_KEY, JSON.stringify(movements))

  return true
}

export function getStockMovements(): StockMovement[] {
  const movements = localStorage.getItem(STOCK_MOVEMENTS_KEY)
  return movements ? JSON.parse(movements) : []
}

// Categories and warehouses
export function getCategories(): string[] {
  const categories = localStorage.getItem(CATEGORIES_KEY)
  return categories ? JSON.parse(categories) : defaultCategories
}

export function getWarehouses(): string[] {
  const warehouses = localStorage.getItem(WAREHOUSES_KEY)
  return warehouses ? JSON.parse(warehouses) : defaultWarehouses
}

export function addCategory(name: string): void {
  const categories = getCategories()
  if (!categories.includes(name)) {
    categories.push(name)
    localStorage.setItem(CATEGORIES_KEY, JSON.stringify(categories))
  }
}

export function addWarehouse(name: string): void {
  const warehouses = getWarehouses()
  if (!warehouses.includes(name)) {
    warehouses.push(name)
    localStorage.setItem(WAREHOUSES_KEY, JSON.stringify(warehouses))
  }
}
