import { supabase } from "./supabase"
import type { Product, Category, Warehouse, Customer, Order, StockMovement } from "./supabase"

// Product Operations
export async function getProducts() {
  const { data, error } = await supabase
    .from("products")
    .select(`
      *,
      category:categories(*),
      inventory:inventory(*)
    `)
    .order("created_at", { ascending: false })

  if (error) throw error
  return data
}

export async function createProduct(product: Omit<Product, "id" | "created_at" | "updated_at">) {
  const { data, error } = await supabase.from("products").insert([product]).select().single()

  if (error) throw error
  return data
}

export async function updateProduct(id: string, updates: Partial<Product>) {
  const { data, error } = await supabase
    .from("products")
    .update({ ...updates, updated_at: new Date().toISOString() })
    .eq("id", id)
    .select()
    .single()

  if (error) throw error
  return data
}

export async function deleteProduct(id: string) {
  const { error } = await supabase.from("products").delete().eq("id", id)
  if (error) throw error
}

// Category Operations
export async function getCategories() {
  const { data, error } = await supabase.from("categories").select("*").order("name")

  if (error) throw error
  return data
}

export async function createCategory(category: Omit<Category, "id" | "created_at" | "updated_at">) {
  const { data, error } = await supabase.from("categories").insert([category]).select().single()

  if (error) throw error
  return data
}

// Warehouse Operations
export async function getWarehouses() {
  const { data, error } = await supabase.from("warehouses").select("*").order("name")

  if (error) throw error
  return data
}

export async function createWarehouse(warehouse: Omit<Warehouse, "id" | "created_at" | "updated_at">) {
  const { data, error } = await supabase.from("warehouses").insert([warehouse]).select().single()

  if (error) throw error
  return data
}

export async function updateWarehouse(id: string, updates: Partial<Warehouse>) {
  const { data, error } = await supabase
    .from("warehouses")
    .update({ ...updates, updated_at: new Date().toISOString() })
    .eq("id", id)
    .select()
    .single()

  if (error) throw error
  return data
}

// Customer Operations
export async function getCustomers() {
  const { data, error } = await supabase.from("customers").select("*").order("created_at", { ascending: false })

  if (error) throw error
  return data
}

export async function createCustomer(customer: Omit<Customer, "id" | "created_at" | "updated_at">) {
  const { data, error } = await supabase.from("customers").insert([customer]).select().single()

  if (error) throw error
  return data
}

export async function updateCustomer(id: string, updates: Partial<Customer>) {
  const { data, error } = await supabase
    .from("customers")
    .update({ ...updates, updated_at: new Date().toISOString() })
    .eq("id", id)
    .select()
    .single()

  if (error) throw error
  return data
}

// Order Operations
export async function getOrders() {
  const { data, error } = await supabase
    .from("orders")
    .select(`
      *,
      customer:customers(*),
      order_items:order_items(*, product:products(*))
    `)
    .order("created_at", { ascending: false })

  if (error) throw error
  return data
}

export async function createOrder(order: Omit<Order, "id" | "created_at" | "updated_at">) {
  const { data, error } = await supabase.from("orders").insert([order]).select().single()

  if (error) throw error
  return data
}

export async function updateOrderStatus(id: string, status: string) {
  const { data, error } = await supabase
    .from("orders")
    .update({ status, updated_at: new Date().toISOString() })
    .eq("id", id)
    .select()
    .single()

  if (error) throw error
  return data
}

// Stock Movement Operations
export async function getStockMovements() {
  const { data, error } = await supabase
    .from("stock_movements")
    .select(`
      *,
      product:products(*),
      warehouse:warehouses(*)
    `)
    .order("created_at", { ascending: false })

  if (error) throw error
  return data
}

export async function createStockMovement(movement: Omit<StockMovement, "id" | "created_at">) {
  const { data, error } = await supabase.from("stock_movements").insert([movement]).select().single()

  if (error) throw error
  return data
}

// Low Stock Products
export async function getLowStockProducts() {
  const { data, error } = await supabase
    .from("products")
    .select(`
      *,
      category:categories(*),
      inventory:inventory(*)
    `)
    .order("created_at", { ascending: false })

  if (error) throw error

  // Filter products where current stock is at or below minimum stock
  return (
    data?.filter((product) => {
      const totalStock = product.inventory?.reduce((sum: number, inv: any) => sum + inv.quantity, 0) || 0
      return totalStock <= product.min_stock
    }) || []
  )
}

// Dashboard Analytics
export async function getDashboardStats() {
  try {
    const [products, orders, customers, lowStock] = await Promise.all([
      getProducts(),
      getOrders(),
      getCustomers(),
      getLowStockProducts(),
    ])

    const totalRevenue = orders?.reduce((sum, order) => sum + order.total_amount, 0) || 0
    const pendingOrders = orders?.filter((order) => order.status === "pending").length || 0
    const totalProducts = products?.length || 0
    const totalCustomers = customers?.length || 0
    const lowStockCount = lowStock?.length || 0

    return {
      totalRevenue,
      pendingOrders,
      totalProducts,
      totalCustomers,
      lowStockCount,
      recentOrders: orders?.slice(0, 5) || [],
      topProducts: products?.slice(0, 5) || [],
    }
  } catch (error) {
    console.error("Error fetching dashboard stats:", error)
    return {
      totalRevenue: 0,
      pendingOrders: 0,
      totalProducts: 0,
      totalCustomers: 0,
      lowStockCount: 0,
      recentOrders: [],
      topProducts: [],
    }
  }
}
