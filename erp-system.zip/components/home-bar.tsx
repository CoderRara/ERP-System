"use client"

import { Button } from "@/components/ui/button"
import { Menu, ChevronRight } from "lucide-react"

interface HomeBarProps {
  onToggleSidebar: () => void
  sidebarOpen: boolean
}

export function HomeBar({ onToggleSidebar, sidebarOpen }: HomeBarProps) {
  return (
    <div className="bg-gray-50 border-b border-gray-200 px-4 py-2 flex items-center">
      <Button
        variant="ghost"
        size="sm"
        onClick={onToggleSidebar}
        className="text-gray-600 hover:text-gray-900 hover:bg-gray-100 flex items-center gap-2"
      >
        {sidebarOpen ? <Menu className="h-4 w-4" /> : <ChevronRight className="h-4 w-4" />}
        <span className="text-sm font-medium">Home</span>
      </Button>
    </div>
  )
}
