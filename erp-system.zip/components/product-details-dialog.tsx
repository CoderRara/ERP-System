"use client"

import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog"
import { getStockMovements, type LocalProduct } from "@/lib/local-storage"
import { Package, DollarSign, Warehouse, Calendar, TrendingUp, TrendingDown, RotateCcw } from "lucide-react"

interface ProductDetailsDialogProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  product: LocalProduct | null
}

export function ProductDetailsDialog({ open, onOpenChange, product }: ProductDetailsDialogProps) {
  if (!product) return null

  const stockMovements = getStockMovements()
    .filter((m) => m.product_id === product.id)
    .slice(0, 5)

  const getStatusBadge = () => {
    if (product.stock === 0) {
      return <Badge variant="destructive">Out of Stock</Badge>
    } else if (product.stock <= product.min_stock) {
      return <Badge variant="secondary">Low Stock</Badge>
    } else {
      return <Badge variant="default">In Stock</Badge>
    }
  }

  const getMovementIcon = (type: string) => {
    switch (type) {
      case "increase":
        return <TrendingUp className="h-4 w-4 text-green-500" />
      case "decrease":
        return <TrendingDown className="h-4 w-4 text-red-500" />
      case "set":
        return <RotateCcw className="h-4 w-4 text-blue-500" />
      default:
        return <Package className="h-4 w-4" />
    }
  }

  const profitMargin = (((product.price - product.cost) / product.price) * 100).toFixed(1)

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[600px]">
        <DialogHeader>
          <DialogTitle>Product Details</DialogTitle>
        </DialogHeader>

        <div className="space-y-6">
          {/* Basic Info */}
          <div className="grid gap-4 md:grid-cols-2">
            <div>
              <h3 className="text-lg font-semibold">{product.name}</h3>
              <p className="text-sm text-gray-600 mt-1">{product.description}</p>
              <div className="flex items-center gap-2 mt-2">
                <Badge variant="outline">{product.sku}</Badge>
                {getStatusBadge()}
              </div>
            </div>
            <div className="space-y-2">
              <div className="flex items-center gap-2">
                <Package className="h-4 w-4 text-gray-500" />
                <span className="text-sm">Category: {product.category}</span>
              </div>
              <div className="flex items-center gap-2">
                <Warehouse className="h-4 w-4 text-gray-500" />
                <span className="text-sm">Warehouse: {product.warehouse}</span>
              </div>
              <div className="flex items-center gap-2">
                <Calendar className="h-4 w-4 text-gray-500" />
                <span className="text-sm">Created: {new Date(product.created_at).toLocaleDateString()}</span>
              </div>
            </div>
          </div>

          {/* Stock & Pricing */}
          <div className="grid gap-4 md:grid-cols-3">
            <div className="p-4 bg-blue-50 rounded-lg">
              <div className="flex items-center gap-2 mb-2">
                <Package className="h-5 w-5 text-blue-600" />
                <span className="font-medium">Stock Level</span>
              </div>
              <p className="text-2xl font-bold text-blue-600">{product.stock}</p>
              <p className="text-sm text-gray-600">Min: {product.min_stock}</p>
            </div>
            <div className="p-4 bg-green-50 rounded-lg">
              <div className="flex items-center gap-2 mb-2">
                <DollarSign className="h-5 w-5 text-green-600" />
                <span className="font-medium">Selling Price</span>
              </div>
              <p className="text-2xl font-bold text-green-600">${product.price}</p>
              <p className="text-sm text-gray-600">Cost: ${product.cost}</p>
            </div>
            <div className="p-4 bg-purple-50 rounded-lg">
              <div className="flex items-center gap-2 mb-2">
                <TrendingUp className="h-5 w-5 text-purple-600" />
                <span className="font-medium">Profit Margin</span>
              </div>
              <p className="text-2xl font-bold text-purple-600">{profitMargin}%</p>
              <p className="text-sm text-gray-600">Profit: ${(product.price - product.cost).toFixed(2)}</p>
            </div>
          </div>

          {/* Recent Stock Movements */}
          <div>
            <h4 className="font-medium mb-3">Recent Stock Movements</h4>
            {stockMovements.length > 0 ? (
              <div className="space-y-2">
                {stockMovements.map((movement) => (
                  <div key={movement.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                    <div className="flex items-center gap-3">
                      {getMovementIcon(movement.type)}
                      <div>
                        <p className="text-sm font-medium capitalize">{movement.type}</p>
                        <p className="text-xs text-gray-600">{new Date(movement.created_at).toLocaleDateString()}</p>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="text-sm font-medium">
                        {movement.type === "set"
                          ? movement.quantity
                          : movement.type === "increase"
                            ? `+${movement.quantity}`
                            : `-${movement.quantity}`}
                      </p>
                      <p className="text-xs text-gray-600">
                        {movement.previous_stock} → {movement.new_stock}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-sm text-gray-500 text-center py-4">No stock movements recorded</p>
            )}
          </div>
        </div>

        <DialogFooter>
          <Button onClick={() => onOpenChange(false)}>Close</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}
