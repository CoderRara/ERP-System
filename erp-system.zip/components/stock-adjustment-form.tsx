"use client"

import type React from "react"
import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog"
import { toast } from "@/hooks/use-toast"
import { adjustStock, type LocalProduct } from "@/lib/local-storage"
import { Loader2, Plus, Minus, RotateCcw } from "lucide-react"

interface StockAdjustmentFormProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  product: LocalProduct | null
  onSuccess: () => void
}

export function StockAdjustmentForm({ open, onOpenChange, product, onSuccess }: StockAdjustmentFormProps) {
  const [loading, setLoading] = useState(false)
  const [formData, setFormData] = useState({
    adjustment_type: "increase" as "increase" | "decrease" | "set",
    quantity: "",
    reason: "",
  })

  useEffect(() => {
    if (open) {
      setFormData({
        adjustment_type: "increase",
        quantity: "",
        reason: "",
      })
    }
  }, [open])

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!product) return

    setLoading(true)

    try {
      const success = adjustStock(product.id, {
        type: formData.adjustment_type,
        quantity: Number.parseInt(formData.quantity),
        reason: formData.reason || undefined,
        warehouse: product.warehouse,
      })

      if (success) {
        toast({
          title: "Success",
          description: "Stock adjusted successfully",
        })
        onSuccess()
        onOpenChange(false)
      } else {
        throw new Error("Failed to adjust stock")
      }
    } catch (error) {
      console.error("Error adjusting stock:", error)
      toast({
        title: "Error",
        description: "Failed to adjust stock",
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  const getNewStock = () => {
    if (!product || !formData.quantity) return product?.stock || 0

    const quantity = Number.parseInt(formData.quantity)
    switch (formData.adjustment_type) {
      case "increase":
        return product.stock + quantity
      case "decrease":
        return Math.max(0, product.stock - quantity)
      case "set":
        return quantity
      default:
        return product.stock
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[500px]">
        <DialogHeader>
          <DialogTitle>Adjust Stock - {product?.name}</DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="p-3 bg-gray-50 rounded-lg">
            <div className="grid grid-cols-2 gap-4 text-sm">
              <div>
                <span className="text-gray-600">Current Stock:</span>
                <span className="font-medium ml-2">{product?.stock || 0} units</span>
              </div>
              <div>
                <span className="text-gray-600">Warehouse:</span>
                <span className="font-medium ml-2">{product?.warehouse}</span>
              </div>
            </div>
          </div>

          <div className="space-y-2">
            <Label>Adjustment Type *</Label>
            <div className="grid grid-cols-3 gap-2">
              <Button
                type="button"
                variant={formData.adjustment_type === "increase" ? "default" : "outline"}
                onClick={() => setFormData({ ...formData, adjustment_type: "increase" })}
                className="flex items-center gap-2"
              >
                <Plus className="h-4 w-4" />
                Increase
              </Button>
              <Button
                type="button"
                variant={formData.adjustment_type === "decrease" ? "default" : "outline"}
                onClick={() => setFormData({ ...formData, adjustment_type: "decrease" })}
                className="flex items-center gap-2"
              >
                <Minus className="h-4 w-4" />
                Decrease
              </Button>
              <Button
                type="button"
                variant={formData.adjustment_type === "set" ? "default" : "outline"}
                onClick={() => setFormData({ ...formData, adjustment_type: "set" })}
                className="flex items-center gap-2"
              >
                <RotateCcw className="h-4 w-4" />
                Set To
              </Button>
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="quantity">
              {formData.adjustment_type === "set" ? "New Quantity" : "Adjustment Quantity"} *
            </Label>
            <Input
              id="quantity"
              type="number"
              min="0"
              value={formData.quantity}
              onChange={(e) => setFormData({ ...formData, quantity: e.target.value })}
              placeholder="Enter quantity"
              required
            />
          </div>

          {formData.quantity && (
            <div className="p-3 bg-blue-50 rounded-lg">
              <p className="text-sm text-blue-800">
                New stock will be: <span className="font-medium">{getNewStock()} units</span>
              </p>
            </div>
          )}

          <div className="space-y-2">
            <Label htmlFor="reason">Reason</Label>
            <Textarea
              id="reason"
              value={formData.reason}
              onChange={(e) => setFormData({ ...formData, reason: e.target.value })}
              placeholder="Reason for stock adjustment"
              rows={3}
            />
          </div>

          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
              Cancel
            </Button>
            <Button type="submit" disabled={loading || !formData.quantity}>
              {loading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              Adjust Stock
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  )
}
