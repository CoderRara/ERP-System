"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Sheet, SheetContent, SheetDescription, SheetHeader, SheetTitle, SheetTrigger } from "@/components/ui/sheet"
import { Badge } from "@/components/ui/badge"
import { Card, CardContent } from "@/components/ui/card"
import {
  Bell,
  Search,
  ChevronDown,
  Droplets,
  User,
  Settings,
  LogOut,
  HelpCircle,
  Keyboard,
  FileText,
  MessageSquare,
} from "lucide-react"
import Link from "next/link"
import { useRouter } from "next/navigation"

export function Navbar() {
  const [searchOpen, setSearchOpen] = useState(false)
  const [searchQuery, setSearchQuery] = useState("")
  const router = useRouter()

  const notifications = [
    {
      id: 1,
      title: "Low Stock Alert",
      message: "USB-C Cable is out of stock",
      time: "5 minutes ago",
      type: "warning",
      unread: true,
    },
    {
      id: 2,
      title: "New Order Received",
      message: "Order #ORD-2024-005 from Tech Solutions Inc",
      time: "1 hour ago",
      type: "info",
      unread: true,
    },
    {
      id: 3,
      title: "Payment Processed",
      message: "Payment of $2,450 has been processed successfully",
      time: "2 hours ago",
      type: "success",
      unread: false,
    },
  ]

  const quickSearchResults = [
    { title: "Products", items: ["Wireless Headphones", "Laptop Stand", "USB-C Cable"], route: "/inventory" },
    { title: "Customers", items: ["Tech Solutions Inc", "Global Retail Co", "Digital Dynamics"], route: "/customers" },
    { title: "Orders", items: ["ORD-001", "ORD-002", "ORD-003"], route: "/orders" },
    { title: "Pages", items: ["Inventory", "Dashboard", "Reports", "Settings"], route: "" },
  ]

  const handleSearch = (query: string) => {
    setSearchQuery(query)
    if (query.toLowerCase().includes("inventory")) {
      router.push("/inventory")
      setSearchOpen(false)
    } else if (query.toLowerCase().includes("dashboard")) {
      router.push("/dashboard")
      setSearchOpen(false)
    } else if (query.toLowerCase().includes("orders")) {
      router.push("/orders")
      setSearchOpen(false)
    }
  }

  const handleLogoClick = () => {
    router.push("/")
  }

  const unreadCount = notifications.filter((n) => n.unread).length

  // Keyboard shortcuts
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey) && e.key === "g") {
        e.preventDefault()
        setSearchOpen(true)
      }
    }
    window.addEventListener("keydown", handleKeyDown)
    return () => window.removeEventListener("keydown", handleKeyDown)
  }, [])

  return (
    <header className="bg-white border-b border-gray-200 px-4 py-3 flex items-center justify-between shadow-sm">
      <div className="flex items-center gap-4">
        <div
          className="flex items-center gap-2 cursor-pointer hover:opacity-80 transition-opacity"
          onClick={handleLogoClick}
        >
          <Droplets className="h-8 w-8 text-blue-600" />
          <div>
            <h1 className="text-xl font-bold text-gray-900">Dr.WaterR</h1>
          </div>
        </div>
      </div>

      <div className="flex items-center gap-4 flex-1 max-w-2xl mx-8">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
          <Input
            placeholder="Search or type a command (Ctrl + G)"
            className="pl-10 bg-gray-50 border-gray-200 focus:border-blue-500 focus:ring-blue-500 cursor-pointer"
            onClick={() => setSearchOpen(true)}
            readOnly
          />
          <Badge variant="outline" className="absolute right-3 top-1/2 transform -translate-y-1/2 text-xs">
            Ctrl+G
          </Badge>
        </div>
      </div>

      <div className="flex items-center gap-3">
        {/* Notifications */}
        <Sheet>
          <SheetTrigger asChild>
            <Button
              variant="ghost"
              size="icon"
              className="relative text-gray-600 hover:text-gray-900 hover:bg-gray-100"
            >
              <Bell className="h-5 w-5" />
              {unreadCount > 0 && (
                <span className="absolute -top-1 -right-1 h-4 w-4 bg-red-500 rounded-full text-xs text-white flex items-center justify-center">
                  {unreadCount}
                </span>
              )}
            </Button>
          </SheetTrigger>
          <SheetContent>
            <SheetHeader>
              <SheetTitle>Notifications</SheetTitle>
              <SheetDescription>Stay updated with your latest activities</SheetDescription>
            </SheetHeader>
            <div className="space-y-4 mt-6">
              {notifications.map((notification) => (
                <Card key={notification.id} className={notification.unread ? "border-blue-200 bg-blue-50" : ""}>
                  <CardContent className="p-4">
                    <div className="flex items-start justify-between">
                      <div className="space-y-1">
                        <h4 className="text-sm font-medium">{notification.title}</h4>
                        <p className="text-sm text-gray-600">{notification.message}</p>
                        <p className="text-xs text-gray-400">{notification.time}</p>
                      </div>
                      {notification.unread && <div className="w-2 h-2 bg-blue-500 rounded-full"></div>}
                    </div>
                  </CardContent>
                </Card>
              ))}
              <Button className="w-full" variant="outline">
                View All Notifications
              </Button>
            </div>
          </SheetContent>
        </Sheet>

        {/* Help Menu */}
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button
              variant="ghost"
              className="text-gray-600 hover:text-gray-900 hover:bg-gray-100 flex items-center gap-2"
            >
              <HelpCircle className="h-4 w-4" />
              <span className="text-sm">Help</span>
              <ChevronDown className="h-4 w-4" />
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end" className="w-56">
            <DropdownMenuLabel>Help & Support</DropdownMenuLabel>
            <DropdownMenuSeparator />
            <DropdownMenuItem asChild>
              <Link href="/help/documentation">
                <FileText className="h-4 w-4 mr-2" />
                Documentation
              </Link>
            </DropdownMenuItem>
            <DropdownMenuItem>
              <Keyboard className="h-4 w-4 mr-2" />
              Keyboard Shortcuts
            </DropdownMenuItem>
            <DropdownMenuItem asChild>
              <Link href="/support">
                <MessageSquare className="h-4 w-4 mr-2" />
                Contact Support
              </Link>
            </DropdownMenuItem>
            <DropdownMenuSeparator />
            <DropdownMenuItem>
              <HelpCircle className="h-4 w-4 mr-2" />
              What's New
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>

        {/* User Profile */}
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="ghost" className="relative h-8 w-8 rounded-full bg-blue-600 text-white hover:bg-blue-700">
              <span className="text-sm font-medium">JD</span>
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent className="w-56" align="end" forceMount>
            <DropdownMenuLabel className="font-normal">
              <div className="flex flex-col space-y-1">
                <p className="text-sm font-medium leading-none">John Doe</p>
                <p className="text-xs leading-none text-muted-foreground">john.doe@drwaterr.com</p>
              </div>
            </DropdownMenuLabel>
            <DropdownMenuSeparator />
            <DropdownMenuItem asChild>
              <Link href="/profile">
                <User className="h-4 w-4 mr-2" />
                Profile
              </Link>
            </DropdownMenuItem>
            <DropdownMenuItem asChild>
              <Link href="/settings">
                <Settings className="h-4 w-4 mr-2" />
                Settings
              </Link>
            </DropdownMenuItem>
            <DropdownMenuSeparator />
            <DropdownMenuItem className="text-red-600">
              <LogOut className="h-4 w-4 mr-2" />
              Log out
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>

      {/* Search Dialog */}
      <Dialog open={searchOpen} onOpenChange={setSearchOpen}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>Search</DialogTitle>
            <DialogDescription>Search for products, customers, orders, or navigate to pages</DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
              <Input
                placeholder="Type to search..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === "Enter") {
                    handleSearch(searchQuery)
                  }
                }}
                className="pl-10"
                autoFocus
              />
            </div>

            {searchQuery === "" && (
              <div className="space-y-4">
                {quickSearchResults.map((section) => (
                  <div key={section.title}>
                    <h4 className="text-sm font-medium text-gray-900 mb-2">{section.title}</h4>
                    <div className="space-y-1">
                      {section.items.map((item) => (
                        <div
                          key={item}
                          className="p-2 hover:bg-gray-50 rounded cursor-pointer text-sm"
                          onClick={() => {
                            setSearchQuery(item)
                            handleSearch(item)
                          }}
                        >
                          {item}
                        </div>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </DialogContent>
      </Dialog>
    </header>
  )
}
