"use client"

import Link from "next/link"
import { usePathname } from "next/navigation"
import { useState } from "react"
import { cn } from "@/lib/utils"
import {
  LayoutDashboard,
  Package,
  Warehouse,
  ShoppingCart,
  Users,
  BarChart3,
  Settings,
  DollarSign,
  ChevronDown,
  ChevronRight,
  Home,
  Building2,
  CreditCard,
  UserCheck,
  Wrench,
  FolderOpen,
  HeadphonesIcon,
  FileText,
  TrendingUp,
  AlertTriangle,
} from "lucide-react"
import { Button } from "@/components/ui/button"

const navigation = [
  {
    section: "PUBLIC",
    items: [
      { name: "Home", href: "/", icon: Home },
      { name: "Dashboard", href: "/dashboard", icon: LayoutDashboard },
    ],
  },
  {
    section: "INVENTORY",
    items: [
      { name: "Products", href: "/inventory", icon: Package },
      { name: "Categories", href: "/inventory/categories", icon: FileText },
      { name: "Low Stock", href: "/inventory/low-stock", icon: AlertTriangle },
      { name: "Stock Movements", href: "/inventory/stock-movements", icon: TrendingUp },
    ],
  },
  {
    section: "OPERATIONS",
    items: [
      { name: "Warehouses", href: "/warehouses", icon: Warehouse },
      { name: "Purchasing", href: "/purchasing", icon: ShoppingCart },
      { name: "Sales", href: "/sales", icon: DollarSign },
      { name: "Orders", href: "/orders", icon: FileText },
    ],
  },
  {
    section: "CONTACTS",
    items: [
      { name: "Customers", href: "/customers", icon: Users },
      { name: "Suppliers", href: "/suppliers", icon: Building2 },
    ],
  },
  {
    section: "FINANCE",
    items: [
      { name: "Accounting", href: "/accounting", icon: CreditCard },
      { name: "Payroll", href: "/payroll", icon: CreditCard },
      { name: "Reports", href: "/reports", icon: BarChart3 },
    ],
  },
  {
    section: "MANAGEMENT",
    items: [
      { name: "HR", href: "/hr", icon: Users },
      { name: "Manufacturing", href: "/manufacturing", icon: Wrench },
      { name: "CRM", href: "/crm", icon: UserCheck },
      { name: "Quality", href: "/quality", icon: BarChart3 },
      { name: "Projects", href: "/projects", icon: FolderOpen },
      { name: "Support", href: "/support", icon: HeadphonesIcon },
      { name: "Settings", href: "/settings", icon: Settings },
    ],
  },
]

interface SidebarProps {
  isOpen: boolean
}

export function Sidebar({ isOpen }: SidebarProps) {
  const pathname = usePathname()
  const [expandedSections, setExpandedSections] = useState<string[]>(["PUBLIC"])

  const toggleSection = (section: string) => {
    setExpandedSections((prev) => (prev.includes(section) ? prev.filter((s) => s !== section) : [...prev, section]))
  }

  if (!isOpen) return null

  return (
    <div className="w-64 bg-white border-r border-gray-200 flex flex-col shadow-sm">
      <div className="flex-1 flex flex-col pt-4 pb-4 overflow-y-auto">
        <nav className="flex-1 px-2 space-y-2">
          {navigation.map((section) => (
            <div key={section.section}>
              <Button
                variant="ghost"
                onClick={() => toggleSection(section.section)}
                className="w-full justify-start px-3 py-2 text-xs font-semibold text-gray-500 uppercase tracking-wider hover:bg-gray-50"
              >
                <div className="flex items-center gap-2">
                  {expandedSections.includes(section.section) ? (
                    <ChevronDown className="h-3 w-3" />
                  ) : (
                    <ChevronRight className="h-3 w-3" />
                  )}
                  {section.section}
                </div>
              </Button>

              {expandedSections.includes(section.section) && (
                <div className="space-y-1 mt-1">
                  {section.items.map((item) => {
                    const Icon = item.icon
                    const isActive = pathname === item.href

                    return (
                      <Link
                        key={item.name}
                        href={item.href}
                        className={cn(
                          "group flex items-center px-2 py-2 text-sm font-medium rounded-md transition-colors ml-4",
                          isActive
                            ? "bg-blue-50 text-blue-700 border-r-2 border-blue-700"
                            : "text-gray-600 hover:bg-gray-50 hover:text-gray-900",
                        )}
                      >
                        <Icon
                          className={cn(
                            "mr-3 flex-shrink-0 h-4 w-4",
                            isActive ? "text-blue-500" : "text-gray-400 group-hover:text-gray-500",
                          )}
                        />
                        {item.name}
                      </Link>
                    )
                  })}
                </div>
              )}
            </div>
          ))}
        </nav>
      </div>
    </div>
  )
}
