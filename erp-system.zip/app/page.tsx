"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import {
  BarChart3,
  Package,
  Warehouse,
  TrendingUp,
  TrendingDown,
  AlertTriangle,
  ShoppingCart,
  DollarSign,
} from "lucide-react"
import Link from "next/link"

export default function Dashboard() {
  const stats = [
    {
      title: "Total Products",
      value: "2,847",
      change: "+12%",
      trend: "up",
      icon: Package,
    },
    {
      title: "Total Revenue",
      value: "$847,392",
      change: "+8.2%",
      trend: "up",
      icon: DollarSign,
    },
    {
      title: "Active Orders",
      value: "156",
      change: "-3%",
      trend: "down",
      icon: ShoppingCart,
    },
    {
      title: "Warehouses",
      value: "12",
      change: "+2",
      trend: "up",
      icon: Warehouse,
    },
  ]

  const lowStockItems = [
    { name: "Wireless Headphones", sku: "WH-001", stock: 5, threshold: 20 },
    { name: "Laptop Stand", sku: "LS-045", stock: 3, threshold: 15 },
    { name: "USB-C Cable", sku: "UC-123", stock: 8, threshold: 25 },
    { name: "Bluetooth Speaker", sku: "BS-789", stock: 2, threshold: 10 },
  ]

  const recentOrders = [
    { id: "ORD-001", customer: "Tech Solutions Inc", amount: "$2,450", status: "Processing" },
    { id: "ORD-002", customer: "Global Retail Co", amount: "$1,890", status: "Shipped" },
    { id: "ORD-003", customer: "Digital Dynamics", amount: "$3,200", status: "Delivered" },
    { id: "ORD-004", customer: "Innovation Labs", amount: "$1,650", status: "Pending" },
  ]

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold text-gray-900">Dashboard</h1>
        <div className="flex gap-2">
          <Button variant="outline">Export Report</Button>
          <Button className="bg-blue-600 hover:bg-blue-700">Generate Invoice</Button>
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        {stats.map((stat) => {
          const Icon = stat.icon
          return (
            <Card key={stat.title} className="bg-white border border-gray-200 shadow-sm">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium text-gray-600">{stat.title}</CardTitle>
                <Icon className="h-4 w-4 text-gray-400" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-gray-900">{stat.value}</div>
                <div className="flex items-center text-xs text-gray-500">
                  {stat.trend === "up" ? (
                    <TrendingUp className="mr-1 h-3 w-3 text-green-500" />
                  ) : (
                    <TrendingDown className="mr-1 h-3 w-3 text-red-500" />
                  )}
                  <span className={stat.trend === "up" ? "text-green-500" : "text-red-500"}>{stat.change}</span>
                  <span className="ml-1">from last month</span>
                </div>
              </CardContent>
            </Card>
          )
        })}
      </div>

      <div className="grid gap-6 md:grid-cols-2">
        {/* Low Stock Alert */}
        <Card className="bg-white border border-gray-200 shadow-sm">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-gray-900">
              <AlertTriangle className="h-5 w-5 text-orange-500" />
              Low Stock Alert
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {lowStockItems.map((item) => (
                <div
                  key={item.sku}
                  className="flex items-center justify-between p-3 border border-gray-200 rounded-lg bg-gray-50"
                >
                  <div>
                    <p className="font-medium text-gray-900">{item.name}</p>
                    <p className="text-sm text-gray-500">SKU: {item.sku}</p>
                  </div>
                  <div className="text-right">
                    <Badge variant="destructive">{item.stock} left</Badge>
                    <p className="text-xs text-gray-500 mt-1">Min: {item.threshold}</p>
                  </div>
                </div>
              ))}
            </div>
            <Button asChild className="w-full mt-4 bg-blue-600 hover:bg-blue-700">
              <Link href="/inventory">View All Inventory</Link>
            </Button>
          </CardContent>
        </Card>

        {/* Recent Orders */}
        <Card className="bg-white border border-gray-200 shadow-sm">
          <CardHeader>
            <CardTitle className="text-gray-900">Recent Orders</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {recentOrders.map((order) => (
                <div
                  key={order.id}
                  className="flex items-center justify-between p-3 border border-gray-200 rounded-lg bg-gray-50"
                >
                  <div>
                    <p className="font-medium text-gray-900">{order.id}</p>
                    <p className="text-sm text-gray-500">{order.customer}</p>
                  </div>
                  <div className="text-right">
                    <p className="font-medium text-gray-900">{order.amount}</p>
                    <Badge
                      variant={
                        order.status === "Delivered"
                          ? "default"
                          : order.status === "Shipped"
                            ? "secondary"
                            : order.status === "Processing"
                              ? "outline"
                              : "destructive"
                      }
                    >
                      {order.status}
                    </Badge>
                  </div>
                </div>
              ))}
            </div>
            <Button asChild variant="outline" className="w-full mt-4">
              <Link href="/orders">View All Orders</Link>
            </Button>
          </CardContent>
        </Card>
      </div>

      {/* Quick Actions */}
      <Card className="bg-white border border-gray-200 shadow-sm">
        <CardHeader>
          <CardTitle className="text-gray-900">Quick Actions</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid gap-4 md:grid-cols-4">
            <Button asChild className="h-20 flex-col bg-blue-600 hover:bg-blue-700">
              <Link href="/inventory/add">
                <Package className="h-6 w-6 mb-2" />
                Add Product
              </Link>
            </Button>
            <Button asChild variant="outline" className="h-20 flex-col">
              <Link href="/orders/new">
                <ShoppingCart className="h-6 w-6 mb-2" />
                New Order
              </Link>
            </Button>
            <Button asChild variant="outline" className="h-20 flex-col">
              <Link href="/warehouses">
                <Warehouse className="h-6 w-6 mb-2" />
                Manage Warehouses
              </Link>
            </Button>
            <Button asChild variant="outline" className="h-20 flex-col">
              <Link href="/reports">
                <BarChart3 className="h-6 w-6 mb-2" />
                View Reports
              </Link>
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
