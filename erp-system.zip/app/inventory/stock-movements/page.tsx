"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import {
  Search,
  TrendingUp,
  TrendingDown,
  Package,
  RefreshCw,
  Download,
  ArrowUpCircle,
  ArrowDownCircle,
  RotateCcw,
} from "lucide-react"
import {
  getStockMovements,
  getProducts,
  initializeData,
  type StockMovement,
  type LocalProduct,
} from "@/lib/local-storage"
import { toast } from "@/hooks/use-toast"

export default function StockMovementsPage() {
  const [searchTerm, setSearchTerm] = useState("")
  const [movements, setMovements] = useState<StockMovement[]>([])
  const [products, setProducts] = useState<LocalProduct[]>([])
  const [loading, setLoading] = useState(true)
  const [typeFilter, setTypeFilter] = useState<string>("all")
  const [dateFilter, setDateFilter] = useState<string>("all")

  useEffect(() => {
    loadData()
  }, [])

  const loadData = async () => {
    try {
      setLoading(true)
      initializeData()
      const movementsData = getStockMovements()
      const productsData = getProducts()
      setMovements(movementsData.sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime()))
      setProducts(productsData)
    } catch (error) {
      console.error("Error loading data:", error)
      toast({
        title: "Error",
        description: "Failed to load stock movements",
        variant: "destructive",
      })
    } finally {
      setLoading(false)
    }
  }

  const getProductName = (productId: string) => {
    const product = products.find((p) => p.id === productId)
    return product ? product.name : "Unknown Product"
  }

  const getProductSku = (productId: string) => {
    const product = products.find((p) => p.id === productId)
    return product ? product.sku : "N/A"
  }

  const filteredMovements = movements.filter((movement) => {
    const product = products.find((p) => p.id === movement.product_id)
    const matchesSearch =
      product?.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      product?.sku.toLowerCase().includes(searchTerm.toLowerCase()) ||
      movement.reason?.toLowerCase().includes(searchTerm.toLowerCase())

    const matchesType = typeFilter === "all" || movement.type === typeFilter

    let matchesDate = true
    if (dateFilter !== "all") {
      const movementDate = new Date(movement.created_at)
      const now = new Date()
      switch (dateFilter) {
        case "today":
          matchesDate = movementDate.toDateString() === now.toDateString()
          break
        case "week":
          const weekAgo = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000)
          matchesDate = movementDate >= weekAgo
          break
        case "month":
          const monthAgo = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000)
          matchesDate = movementDate >= monthAgo
          break
      }
    }

    return matchesSearch && matchesType && matchesDate
  })

  const totalMovements = movements.length
  const increasesCount = movements.filter((m) => m.type === "increase").length
  const decreasesCount = movements.filter((m) => m.type === "decrease").length
  const adjustmentsCount = movements.filter((m) => m.type === "set").length

  const getMovementIcon = (type: string) => {
    switch (type) {
      case "increase":
        return <ArrowUpCircle className="h-4 w-4 text-green-500" />
      case "decrease":
        return <ArrowDownCircle className="h-4 w-4 text-red-500" />
      case "set":
        return <RotateCcw className="h-4 w-4 text-blue-500" />
      default:
        return <Package className="h-4 w-4" />
    }
  }

  const getMovementBadge = (type: string) => {
    switch (type) {
      case "increase":
        return <Badge className="bg-green-100 text-green-800">Stock In</Badge>
      case "decrease":
        return <Badge className="bg-red-100 text-red-800">Stock Out</Badge>
      case "set":
        return <Badge className="bg-blue-100 text-blue-800">Adjustment</Badge>
      default:
        return <Badge variant="secondary">{type}</Badge>
    }
  }

  const exportToCSV = () => {
    const headers = ["Date", "Product", "SKU", "Type", "Quantity", "Previous Stock", "New Stock", "Reason", "Warehouse"]
    const csvData = [
      headers.join(","),
      ...filteredMovements.map((m) =>
        [
          new Date(m.created_at).toLocaleDateString(),
          `"${getProductName(m.product_id)}"`,
          getProductSku(m.product_id),
          m.type,
          m.quantity,
          m.previous_stock,
          m.new_stock,
          `"${m.reason || ""}"`,
          `"${m.warehouse}"`,
        ].join(","),
      ),
    ].join("\n")

    const blob = new Blob([csvData], { type: "text/csv" })
    const url = window.URL.createObjectURL(blob)
    const a = document.createElement("a")
    a.href = url
    a.download = `stock-movements-${new Date().toISOString().split("T")[0]}.csv`
    a.click()
    window.URL.revokeObjectURL(url)
  }

  if (loading) {
    return (
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <h1 className="text-3xl font-bold">Stock Movements</h1>
        </div>
        <div className="grid gap-4 md:grid-cols-4">
          {[1, 2, 3, 4].map((i) => (
            <Card key={i}>
              <CardContent className="p-6">
                <div className="animate-pulse space-y-2">
                  <div className="h-4 bg-gray-200 rounded w-3/4"></div>
                  <div className="h-8 bg-gray-200 rounded w-1/2"></div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold">Stock Movements</h1>
        <div className="flex gap-2">
          <Button variant="outline" onClick={exportToCSV}>
            <Download className="h-4 w-4 mr-2" />
            Export CSV
          </Button>
          <Button variant="outline" onClick={loadData}>
            <RefreshCw className="h-4 w-4 mr-2" />
            Refresh
          </Button>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid gap-4 md:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Movements</CardTitle>
            <Package className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{totalMovements}</div>
            <p className="text-xs text-muted-foreground">All time movements</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Stock Increases</CardTitle>
            <TrendingUp className="h-4 w-4 text-green-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-500">{increasesCount}</div>
            <p className="text-xs text-muted-foreground">Stock additions</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Stock Decreases</CardTitle>
            <TrendingDown className="h-4 w-4 text-red-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-red-500">{decreasesCount}</div>
            <p className="text-xs text-muted-foreground">Stock reductions</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Adjustments</CardTitle>
            <RotateCcw className="h-4 w-4 text-blue-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-blue-500">{adjustmentsCount}</div>
            <p className="text-xs text-muted-foreground">Stock adjustments</p>
          </CardContent>
        </Card>
      </div>

      {/* Filters */}
      <Card>
        <CardHeader>
          <div className="flex items-center gap-4 flex-wrap">
            <div className="relative flex-1 max-w-md">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
              <Input
                placeholder="Search movements..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
            <Select value={typeFilter} onValueChange={setTypeFilter}>
              <SelectTrigger className="w-40">
                <SelectValue placeholder="Movement Type" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Types</SelectItem>
                <SelectItem value="increase">Stock In</SelectItem>
                <SelectItem value="decrease">Stock Out</SelectItem>
                <SelectItem value="set">Adjustment</SelectItem>
              </SelectContent>
            </Select>
            <Select value={dateFilter} onValueChange={setDateFilter}>
              <SelectTrigger className="w-40">
                <SelectValue placeholder="Date Range" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Time</SelectItem>
                <SelectItem value="today">Today</SelectItem>
                <SelectItem value="week">Last Week</SelectItem>
                <SelectItem value="month">Last Month</SelectItem>
              </SelectContent>
            </Select>
            <Badge variant="outline">{filteredMovements.length} movements</Badge>
          </div>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Date & Time</TableHead>
                <TableHead>Product</TableHead>
                <TableHead>Type</TableHead>
                <TableHead>Quantity</TableHead>
                <TableHead>Previous Stock</TableHead>
                <TableHead>New Stock</TableHead>
                <TableHead>Reason</TableHead>
                <TableHead>Warehouse</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredMovements.map((movement) => (
                <TableRow key={movement.id} className="hover:bg-gray-50">
                  <TableCell>
                    <div>
                      <div className="font-medium">{new Date(movement.created_at).toLocaleDateString()}</div>
                      <div className="text-sm text-muted-foreground">
                        {new Date(movement.created_at).toLocaleTimeString()}
                      </div>
                    </div>
                  </TableCell>
                  <TableCell>
                    <div>
                      <div className="font-medium">{getProductName(movement.product_id)}</div>
                      <div className="text-sm text-muted-foreground">{getProductSku(movement.product_id)}</div>
                    </div>
                  </TableCell>
                  <TableCell>
                    <div className="flex items-center gap-2">
                      {getMovementIcon(movement.type)}
                      {getMovementBadge(movement.type)}
                    </div>
                  </TableCell>
                  <TableCell>
                    <span className="font-medium">{movement.quantity}</span>
                  </TableCell>
                  <TableCell>
                    <span className="text-muted-foreground">{movement.previous_stock}</span>
                  </TableCell>
                  <TableCell>
                    <span className="font-medium">{movement.new_stock}</span>
                  </TableCell>
                  <TableCell>
                    <span className="text-sm">{movement.reason || "No reason provided"}</span>
                  </TableCell>
                  <TableCell>
                    <Badge variant="outline">{movement.warehouse}</Badge>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>

          {filteredMovements.length === 0 && (
            <div className="text-center py-8">
              <Package className="h-12 w-12 text-gray-400 mx-auto mb-4" />
              <h3 className="text-lg font-medium text-gray-900 mb-2">No stock movements found</h3>
              <p className="text-gray-500">
                {searchTerm || typeFilter !== "all" || dateFilter !== "all"
                  ? "Try adjusting your filters"
                  : "Stock movements will appear here when inventory changes are made"}
              </p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
