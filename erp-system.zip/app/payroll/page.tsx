"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Input } from "@/components/ui/input"
import { Users, DollarSign, Calendar, TrendingUp, Plus, Search, Download, Clock, Calculator } from "lucide-react"

export default function PayrollPage() {
  const [searchTerm, setSearchTerm] = useState("")

  const payrollData = [
    {
      id: "EMP-001",
      name: "John Smith",
      position: "Sales Manager",
      department: "Sales",
      baseSalary: 75000,
      hoursWorked: 160,
      overtime: 8,
      grossPay: 6458.33,
      deductions: 1291.67,
      netPay: 5166.66,
      status: "Processed",
    },
    {
      id: "EMP-002",
      name: "Sarah Johnson",
      position: "VP Sales",
      department: "Sales",
      baseSalary: 95000,
      hoursWorked: 160,
      overtime: 0,
      grossPay: 7916.67,
      deductions: 1583.33,
      netPay: 6333.34,
      status: "Processed",
    },
    {
      id: "EMP-003",
      name: "Mike Davis",
      position: "Warehouse Manager",
      department: "Operations",
      baseSalary: 65000,
      hoursWorked: 160,
      overtime: 12,
      grossPay: 5708.33,
      deductions: 1141.67,
      netPay: 4566.66,
      status: "Pending",
    },
    {
      id: "EMP-004",
      name: "Lisa Wilson",
      position: "Operations Director",
      department: "Operations",
      baseSalary: 85000,
      hoursWorked: 160,
      overtime: 4,
      grossPay: 7291.67,
      deductions: 1458.33,
      netPay: 5833.34,
      status: "Processed",
    },
  ]

  const payrollSummary = {
    totalEmployees: payrollData.length,
    totalGrossPay: payrollData.reduce((sum, emp) => sum + emp.grossPay, 0),
    totalDeductions: payrollData.reduce((sum, emp) => sum + emp.deductions, 0),
    totalNetPay: payrollData.reduce((sum, emp) => sum + emp.netPay, 0),
    totalOvertimeHours: payrollData.reduce((sum, emp) => sum + emp.overtime, 0),
  }

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "Processed":
        return <Badge className="bg-green-600">Processed</Badge>
      case "Pending":
        return <Badge variant="secondary">Pending</Badge>
      case "Failed":
        return <Badge variant="destructive">Failed</Badge>
      default:
        return <Badge variant="outline">{status}</Badge>
    }
  }

  const filteredPayroll = payrollData.filter(
    (emp) =>
      emp.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      emp.department.toLowerCase().includes(searchTerm.toLowerCase()),
  )

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold">Payroll Management</h1>
        <div className="flex gap-2">
          <Button variant="outline">
            <Calendar className="h-4 w-4 mr-2" />
            January 2024
          </Button>
          <Button variant="outline">
            <Download className="h-4 w-4 mr-2" />
            Export
          </Button>
          <Button>
            <Plus className="h-4 w-4 mr-2" />
            Process Payroll
          </Button>
        </div>
      </div>

      {/* Payroll Summary */}
      <div className="grid gap-4 md:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Employees</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{payrollSummary.totalEmployees}</div>
            <p className="text-xs text-muted-foreground">Active employees</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Gross Pay</CardTitle>
            <DollarSign className="h-4 w-4 text-green-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">${payrollSummary.totalGrossPay.toLocaleString()}</div>
            <p className="text-xs text-muted-foreground">Before deductions</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Net Pay</CardTitle>
            <Calculator className="h-4 w-4 text-blue-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">${payrollSummary.totalNetPay.toLocaleString()}</div>
            <p className="text-xs text-muted-foreground">After deductions</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Overtime Hours</CardTitle>
            <Clock className="h-4 w-4 text-orange-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{payrollSummary.totalOvertimeHours}</div>
            <p className="text-xs text-muted-foreground">Total overtime</p>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="current" className="space-y-4">
        <TabsList>
          <TabsTrigger value="current">Current Payroll</TabsTrigger>
          <TabsTrigger value="history">Payroll History</TabsTrigger>
          <TabsTrigger value="settings">Payroll Settings</TabsTrigger>
          <TabsTrigger value="reports">Reports</TabsTrigger>
        </TabsList>

        <TabsContent value="current">
          <Card>
            <CardHeader>
              <div className="flex items-center gap-4">
                <div className="relative flex-1 max-w-md">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                  <Input
                    placeholder="Search employees..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-10"
                  />
                </div>
                <Badge variant="outline">{filteredPayroll.length} employees</Badge>
              </div>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Employee</TableHead>
                    <TableHead>Department</TableHead>
                    <TableHead>Hours</TableHead>
                    <TableHead>Overtime</TableHead>
                    <TableHead>Gross Pay</TableHead>
                    <TableHead>Deductions</TableHead>
                    <TableHead>Net Pay</TableHead>
                    <TableHead>Status</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredPayroll.map((employee) => (
                    <TableRow key={employee.id}>
                      <TableCell>
                        <div>
                          <div className="font-medium">{employee.name}</div>
                          <div className="text-sm text-muted-foreground">{employee.position}</div>
                        </div>
                      </TableCell>
                      <TableCell>
                        <Badge variant="outline">{employee.department}</Badge>
                      </TableCell>
                      <TableCell>{employee.hoursWorked}h</TableCell>
                      <TableCell>
                        {employee.overtime > 0 ? (
                          <span className="text-orange-600">{employee.overtime}h</span>
                        ) : (
                          <span className="text-gray-400">0h</span>
                        )}
                      </TableCell>
                      <TableCell>${employee.grossPay.toLocaleString()}</TableCell>
                      <TableCell className="text-red-600">-${employee.deductions.toLocaleString()}</TableCell>
                      <TableCell className="font-medium">${employee.netPay.toLocaleString()}</TableCell>
                      <TableCell>{getStatusBadge(employee.status)}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="history">
          <Card>
            <CardHeader>
              <CardTitle>Payroll History</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-center py-8">
                <Calendar className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                <h3 className="text-lg font-medium text-gray-900 mb-2">Payroll History</h3>
                <p className="text-gray-500 mb-4">View historical payroll data and reports</p>
                <Button>View History</Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="settings">
          <Card>
            <CardHeader>
              <CardTitle>Payroll Settings</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                <div className="grid gap-4 md:grid-cols-2">
                  <Card>
                    <CardContent className="pt-6">
                      <div className="text-center">
                        <Calculator className="h-8 w-8 text-blue-500 mx-auto mb-2" />
                        <h4 className="font-medium">Tax Settings</h4>
                        <p className="text-sm text-muted-foreground">Configure tax rates and deductions</p>
                        <Button className="mt-2" size="sm">
                          Configure
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                  <Card>
                    <CardContent className="pt-6">
                      <div className="text-center">
                        <Clock className="h-8 w-8 text-green-500 mx-auto mb-2" />
                        <h4 className="font-medium">Pay Periods</h4>
                        <p className="text-sm text-muted-foreground">Set up pay schedules</p>
                        <Button className="mt-2" size="sm">
                          Configure
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="reports">
          <Card>
            <CardHeader>
              <CardTitle>Payroll Reports</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid gap-4 md:grid-cols-3">
                <Card>
                  <CardContent className="pt-6">
                    <div className="text-center">
                      <TrendingUp className="h-8 w-8 text-blue-500 mx-auto mb-2" />
                      <h4 className="font-medium">Payroll Summary</h4>
                      <p className="text-sm text-muted-foreground">Monthly payroll overview</p>
                      <Button className="mt-2" size="sm">
                        Generate
                      </Button>
                    </div>
                  </CardContent>
                </Card>
                <Card>
                  <CardContent className="pt-6">
                    <div className="text-center">
                      <Users className="h-8 w-8 text-green-500 mx-auto mb-2" />
                      <h4 className="font-medium">Employee Report</h4>
                      <p className="text-sm text-muted-foreground">Individual pay statements</p>
                      <Button className="mt-2" size="sm">
                        Generate
                      </Button>
                    </div>
                  </CardContent>
                </Card>
                <Card>
                  <CardContent className="pt-6">
                    <div className="text-center">
                      <Calculator className="h-8 w-8 text-purple-500 mx-auto mb-2" />
                      <h4 className="font-medium">Tax Report</h4>
                      <p className="text-sm text-muted-foreground">Tax withholdings and filings</p>
                      <Button className="mt-2" size="sm">
                        Generate
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
