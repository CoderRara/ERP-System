"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  Search,
  FileText,
  Video,
  Download,
  ExternalLink,
  BookOpen,
  HelpCircle,
  Lightbulb,
  Settings,
  Users,
  Package,
  BarChart3,
} from "lucide-react"

export default function DocumentationPage() {
  const [searchTerm, setSearchTerm] = useState("")

  const documentationSections = [
    {
      title: "Getting Started",
      icon: BookOpen,
      articles: [
        { title: "System Overview", type: "article", duration: "5 min read" },
        { title: "First Time Setup", type: "video", duration: "10 min" },
        { title: "User Interface Guide", type: "article", duration: "8 min read" },
        { title: "Navigation Basics", type: "article", duration: "3 min read" },
      ],
    },
    {
      title: "Inventory Management",
      icon: Package,
      articles: [
        { title: "Adding Products", type: "article", duration: "4 min read" },
        { title: "Stock Management", type: "video", duration: "12 min" },
        { title: "Category Management", type: "article", duration: "6 min read" },
        { title: "Inventory Reports", type: "article", duration: "7 min read" },
      ],
    },
    {
      title: "User Management",
      icon: Users,
      articles: [
        { title: "Creating User Accounts", type: "article", duration: "5 min read" },
        { title: "Role Permissions", type: "article", duration: "8 min read" },
        { title: "Security Settings", type: "video", duration: "15 min" },
        { title: "User Activity Monitoring", type: "article", duration: "6 min read" },
      ],
    },
    {
      title: "Reports & Analytics",
      icon: BarChart3,
      articles: [
        { title: "Generating Reports", type: "video", duration: "18 min" },
        { title: "Custom Dashboards", type: "article", duration: "10 min read" },
        { title: "Data Export Options", type: "article", duration: "4 min read" },
        { title: "Analytics Overview", type: "article", duration: "12 min read" },
      ],
    },
    {
      title: "System Configuration",
      icon: Settings,
      articles: [
        { title: "General Settings", type: "article", duration: "6 min read" },
        { title: "Integration Setup", type: "video", duration: "20 min" },
        { title: "Backup & Recovery", type: "article", duration: "8 min read" },
        { title: "Performance Optimization", type: "article", duration: "15 min read" },
      ],
    },
  ]

  const quickLinks = [
    { title: "Keyboard Shortcuts", icon: HelpCircle },
    { title: "API Documentation", icon: FileText },
    { title: "Video Tutorials", icon: Video },
    { title: "Best Practices", icon: Lightbulb },
  ]

  const getTypeIcon = (type: string) => {
    return type === "video" ? Video : FileText
  }

  const getTypeBadge = (type: string) => {
    return type === "video" ? <Badge variant="secondary">Video</Badge> : <Badge variant="outline">Article</Badge>
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold">Documentation</h1>
        <div className="flex gap-2">
          <Button variant="outline">
            <Download className="h-4 w-4 mr-2" />
            Download PDF
          </Button>
          <Button variant="outline">
            <ExternalLink className="h-4 w-4 mr-2" />
            Online Help
          </Button>
        </div>
      </div>

      {/* Search */}
      <Card>
        <CardContent className="pt-6">
          <div className="relative max-w-md mx-auto">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
            <Input
              placeholder="Search documentation..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
            />
          </div>
        </CardContent>
      </Card>

      {/* Quick Links */}
      <div className="grid gap-4 md:grid-cols-4">
        {quickLinks.map((link) => {
          const Icon = link.icon
          return (
            <Card key={link.title} className="cursor-pointer hover:shadow-md transition-shadow">
              <CardContent className="pt-6">
                <div className="text-center">
                  <Icon className="h-8 w-8 text-blue-500 mx-auto mb-2" />
                  <h4 className="font-medium">{link.title}</h4>
                </div>
              </CardContent>
            </Card>
          )
        })}
      </div>

      <Tabs defaultValue="all" className="space-y-4">
        <TabsList>
          <TabsTrigger value="all">All Documentation</TabsTrigger>
          <TabsTrigger value="articles">Articles</TabsTrigger>
          <TabsTrigger value="videos">Videos</TabsTrigger>
          <TabsTrigger value="downloads">Downloads</TabsTrigger>
        </TabsList>

        <TabsContent value="all">
          <div className="space-y-6">
            {documentationSections.map((section) => {
              const Icon = section.icon
              return (
                <Card key={section.title}>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Icon className="h-5 w-5" />
                      {section.title}
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="grid gap-3 md:grid-cols-2">
                      {section.articles.map((article) => {
                        const TypeIcon = getTypeIcon(article.type)
                        return (
                          <div
                            key={article.title}
                            className="flex items-center justify-between p-3 border rounded-lg hover:bg-gray-50 cursor-pointer"
                          >
                            <div className="flex items-center gap-3">
                              <TypeIcon className="h-4 w-4 text-muted-foreground" />
                              <div>
                                <h4 className="font-medium">{article.title}</h4>
                                <p className="text-sm text-muted-foreground">{article.duration}</p>
                              </div>
                            </div>
                            <div className="flex items-center gap-2">
                              {getTypeBadge(article.type)}
                              <ExternalLink className="h-4 w-4 text-muted-foreground" />
                            </div>
                          </div>
                        )
                      })}
                    </div>
                  </CardContent>
                </Card>
              )
            })}
          </div>
        </TabsContent>

        <TabsContent value="articles">
          <Card>
            <CardHeader>
              <CardTitle>Help Articles</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-center py-8">
                <FileText className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                <h3 className="text-lg font-medium text-gray-900 mb-2">Article Library</h3>
                <p className="text-gray-500 mb-4">Browse our comprehensive article collection</p>
                <Button>Browse Articles</Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="videos">
          <Card>
            <CardHeader>
              <CardTitle>Video Tutorials</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-center py-8">
                <Video className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                <h3 className="text-lg font-medium text-gray-900 mb-2">Video Library</h3>
                <p className="text-gray-500 mb-4">Watch step-by-step video tutorials</p>
                <Button>Watch Videos</Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="downloads">
          <Card>
            <CardHeader>
              <CardTitle>Downloads</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex items-center justify-between p-4 border rounded-lg">
                  <div className="flex items-center gap-3">
                    <FileText className="h-8 w-8 text-blue-500" />
                    <div>
                      <h4 className="font-medium">User Manual (PDF)</h4>
                      <p className="text-sm text-muted-foreground">Complete user guide - 45 pages</p>
                    </div>
                  </div>
                  <Button variant="outline" size="sm">
                    <Download className="h-4 w-4 mr-2" />
                    Download
                  </Button>
                </div>
                <div className="flex items-center justify-between p-4 border rounded-lg">
                  <div className="flex items-center gap-3">
                    <FileText className="h-8 w-8 text-green-500" />
                    <div>
                      <h4 className="font-medium">Quick Reference Guide</h4>
                      <p className="text-sm text-muted-foreground">Essential shortcuts and tips - 8 pages</p>
                    </div>
                  </div>
                  <Button variant="outline" size="sm">
                    <Download className="h-4 w-4 mr-2" />
                    Download
                  </Button>
                </div>
                <div className="flex items-center justify-between p-4 border rounded-lg">
                  <div className="flex items-center gap-3">
                    <FileText className="h-8 w-8 text-purple-500" />
                    <div>
                      <h4 className="font-medium">API Documentation</h4>
                      <p className="text-sm text-muted-foreground">Developer reference - 120 pages</p>
                    </div>
                  </div>
                  <Button variant="outline" size="sm">
                    <Download className="h-4 w-4 mr-2" />
                    Download
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
