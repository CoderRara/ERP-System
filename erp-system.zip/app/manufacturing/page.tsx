"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Progress } from "@/components/ui/progress"
import {
  Search,
  Filter,
  Plus,
  MoreHorizontal,
  Edit,
  Eye,
  Wrench,
  Calendar,
  Clock,
  Package,
  Settings,
  AlertTriangle,
  CheckCircle,
  TrendingUp,
  Factory,
} from "lucide-react"

export default function ManufacturingPage() {
  const [searchTerm, setSearchTerm] = useState("")

  const workOrders = [
    {
      id: "WO-001",
      orderNumber: "MFG-2024-001",
      product: "Wireless Headphones",
      quantity: 500,
      produced: 350,
      startDate: "2024-01-10",
      dueDate: "2024-01-25",
      status: "In Progress",
      priority: "High",
      workstation: "Assembly Line 1",
      operator: "John Smith",
    },
    {
      id: "WO-002",
      orderNumber: "MFG-2024-002",
      product: "Laptop Stand",
      quantity: 200,
      produced: 200,
      startDate: "2024-01-08",
      dueDate: "2024-01-20",
      status: "Completed",
      priority: "Medium",
      workstation: "Assembly Line 2",
      operator: "Sarah Johnson",
    },
    {
      id: "WO-003",
      orderNumber: "MFG-2024-003",
      product: "USB-C Cable",
      quantity: 1000,
      produced: 0,
      startDate: "2024-01-20",
      dueDate: "2024-02-05",
      status: "Scheduled",
      priority: "Low",
      workstation: "Assembly Line 3",
      operator: "Mike Davis",
    },
    {
      id: "WO-004",
      orderNumber: "MFG-2024-004",
      product: "Bluetooth Speaker",
      quantity: 300,
      produced: 150,
      startDate: "2024-01-15",
      dueDate: "2024-01-30",
      status: "In Progress",
      priority: "High",
      workstation: "Assembly Line 1",
      operator: "Lisa Wilson",
    },
  ]

  const equipment = [
    {
      id: "EQ-001",
      name: "Assembly Line 1",
      type: "Production Line",
      status: "Running",
      efficiency: 85,
      lastMaintenance: "2024-01-01",
      nextMaintenance: "2024-02-01",
      location: "Floor A",
    },
    {
      id: "EQ-002",
      name: "Assembly Line 2",
      type: "Production Line",
      status: "Idle",
      efficiency: 92,
      lastMaintenance: "2024-01-05",
      nextMaintenance: "2024-02-05",
      location: "Floor A",
    },
    {
      id: "EQ-003",
      name: "Quality Control Station",
      type: "Testing Equipment",
      status: "Running",
      efficiency: 78,
      lastMaintenance: "2023-12-20",
      nextMaintenance: "2024-01-20",
      location: "Floor B",
    },
    {
      id: "EQ-004",
      name: "Packaging Machine",
      type: "Packaging",
      status: "Maintenance",
      efficiency: 0,
      lastMaintenance: "2024-01-15",
      nextMaintenance: "2024-01-16",
      location: "Floor C",
    },
  ]

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "Completed":
        return <Badge className="bg-green-600 hover:bg-green-700">Completed</Badge>
      case "In Progress":
        return <Badge variant="default">In Progress</Badge>
      case "Scheduled":
        return <Badge variant="secondary">Scheduled</Badge>
      case "On Hold":
        return <Badge variant="destructive">On Hold</Badge>
      default:
        return <Badge variant="outline">{status}</Badge>
    }
  }

  const getPriorityBadge = (priority: string) => {
    switch (priority) {
      case "High":
        return <Badge variant="destructive">High</Badge>
      case "Medium":
        return <Badge variant="secondary">Medium</Badge>
      case "Low":
        return <Badge variant="outline">Low</Badge>
      default:
        return <Badge variant="outline">{priority}</Badge>
    }
  }

  const getEquipmentStatusBadge = (status: string) => {
    switch (status) {
      case "Running":
        return <Badge className="bg-green-600 hover:bg-green-700">Running</Badge>
      case "Idle":
        return <Badge variant="secondary">Idle</Badge>
      case "Maintenance":
        return <Badge variant="destructive">Maintenance</Badge>
      default:
        return <Badge variant="outline">{status}</Badge>
    }
  }

  const filteredWorkOrders = workOrders.filter(
    (order) =>
      order.orderNumber.toLowerCase().includes(searchTerm.toLowerCase()) ||
      order.product.toLowerCase().includes(searchTerm.toLowerCase()) ||
      order.operator.toLowerCase().includes(searchTerm.toLowerCase()),
  )

  const totalOrders = workOrders.length
  const completedOrders = workOrders.filter((o) => o.status === "Completed").length
  const inProgressOrders = workOrders.filter((o) => o.status === "In Progress").length
  const totalProduction = workOrders.reduce((sum, o) => sum + o.produced, 0)

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold text-gray-900">Manufacturing</h1>
        <div className="flex gap-2">
          <Button variant="outline">
            <Filter className="h-4 w-4 mr-2" />
            Filter
          </Button>
          <Button>
            <Plus className="h-4 w-4 mr-2" />
            New Work Order
          </Button>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid gap-4 md:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Work Orders</CardTitle>
            <Wrench className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{totalOrders}</div>
            <div className="flex items-center text-xs text-green-500">
              <TrendingUp className="mr-1 h-3 w-3" />
              +8% from last month
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Completed Orders</CardTitle>
            <CheckCircle className="h-4 w-4 text-green-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-500">{completedOrders}</div>
            <div className="text-xs text-gray-500">
              {Math.round((completedOrders / totalOrders) * 100)}% completion rate
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">In Progress</CardTitle>
            <Clock className="h-4 w-4 text-blue-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-blue-500">{inProgressOrders}</div>
            <div className="text-xs text-gray-500">Currently active</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Production</CardTitle>
            <Package className="h-4 w-4 text-purple-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{totalProduction.toLocaleString()}</div>
            <div className="text-xs text-gray-500">Units produced</div>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="work-orders" className="space-y-4">
        <TabsList>
          <TabsTrigger value="work-orders">Work Orders</TabsTrigger>
          <TabsTrigger value="equipment">Equipment</TabsTrigger>
          <TabsTrigger value="production">Production Planning</TabsTrigger>
          <TabsTrigger value="quality">Quality Control</TabsTrigger>
        </TabsList>

        <TabsContent value="work-orders">
          <Card>
            <CardHeader>
              <div className="flex items-center gap-4">
                <div className="relative flex-1 max-w-md">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                  <Input
                    placeholder="Search work orders..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-10"
                  />
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Work Order</TableHead>
                    <TableHead>Product</TableHead>
                    <TableHead>Progress</TableHead>
                    <TableHead>Dates</TableHead>
                    <TableHead>Workstation</TableHead>
                    <TableHead>Priority</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredWorkOrders.map((order) => {
                    const progress = (order.produced / order.quantity) * 100
                    return (
                      <TableRow key={order.id}>
                        <TableCell>
                          <div>
                            <div className="font-medium">{order.orderNumber}</div>
                            <div className="text-sm text-muted-foreground">{order.id}</div>
                          </div>
                        </TableCell>
                        <TableCell className="font-medium">{order.product}</TableCell>
                        <TableCell>
                          <div className="space-y-2">
                            <div className="flex justify-between text-sm">
                              <span>
                                {order.produced}/{order.quantity}
                              </span>
                              <span>{Math.round(progress)}%</span>
                            </div>
                            <Progress value={progress} className="h-2" />
                          </div>
                        </TableCell>
                        <TableCell>
                          <div className="space-y-1">
                            <div className="flex items-center gap-2 text-sm">
                              <Calendar className="h-3 w-3" />
                              Start: {order.startDate}
                            </div>
                            <div className="flex items-center gap-2 text-sm">
                              <Clock className="h-3 w-3" />
                              Due: {order.dueDate}
                            </div>
                          </div>
                        </TableCell>
                        <TableCell>
                          <div>
                            <div className="font-medium">{order.workstation}</div>
                            <div className="text-sm text-muted-foreground">{order.operator}</div>
                          </div>
                        </TableCell>
                        <TableCell>{getPriorityBadge(order.priority)}</TableCell>
                        <TableCell>{getStatusBadge(order.status)}</TableCell>
                        <TableCell className="text-right">
                          <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                              <Button variant="ghost" size="icon">
                                <MoreHorizontal className="h-4 w-4" />
                              </Button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent align="end">
                              <DropdownMenuItem>
                                <Eye className="h-4 w-4 mr-2" />
                                View Details
                              </DropdownMenuItem>
                              <DropdownMenuItem>
                                <Edit className="h-4 w-4 mr-2" />
                                Edit Order
                              </DropdownMenuItem>
                              <DropdownMenuItem>
                                <Package className="h-4 w-4 mr-2" />
                                Update Progress
                              </DropdownMenuItem>
                            </DropdownMenuContent>
                          </DropdownMenu>
                        </TableCell>
                      </TableRow>
                    )
                  })}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="equipment">
          <Card>
            <CardHeader>
              <CardTitle>Equipment Status</CardTitle>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Equipment</TableHead>
                    <TableHead>Type</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Efficiency</TableHead>
                    <TableHead>Last Maintenance</TableHead>
                    <TableHead>Next Maintenance</TableHead>
                    <TableHead>Location</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {equipment.map((item) => (
                    <TableRow key={item.id}>
                      <TableCell>
                        <div>
                          <div className="font-medium">{item.name}</div>
                          <div className="text-sm text-muted-foreground">{item.id}</div>
                        </div>
                      </TableCell>
                      <TableCell>
                        <Badge variant="outline">{item.type}</Badge>
                      </TableCell>
                      <TableCell>{getEquipmentStatusBadge(item.status)}</TableCell>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          <Progress value={item.efficiency} className="h-2 w-16" />
                          <span className="text-sm">{item.efficiency}%</span>
                        </div>
                      </TableCell>
                      <TableCell>{item.lastMaintenance}</TableCell>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          {new Date(item.nextMaintenance) < new Date() && (
                            <AlertTriangle className="h-4 w-4 text-red-500" />
                          )}
                          {item.nextMaintenance}
                        </div>
                      </TableCell>
                      <TableCell>{item.location}</TableCell>
                      <TableCell className="text-right">
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" size="icon">
                              <MoreHorizontal className="h-4 w-4" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuItem>
                              <Eye className="h-4 w-4 mr-2" />
                              View Details
                            </DropdownMenuItem>
                            <DropdownMenuItem>
                              <Settings className="h-4 w-4 mr-2" />
                              Schedule Maintenance
                            </DropdownMenuItem>
                            <DropdownMenuItem>
                              <Wrench className="h-4 w-4 mr-2" />
                              Maintenance Log
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="production">
          <Card>
            <CardHeader>
              <CardTitle>Production Planning</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-center py-8">
                <Factory className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                <h3 className="text-lg font-medium text-gray-900 mb-2">Production Scheduling</h3>
                <p className="text-gray-500 mb-4">Plan and schedule production runs for optimal efficiency</p>
                <Button>Create Production Plan</Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="quality">
          <Card>
            <CardHeader>
              <CardTitle>Quality Control</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-center py-8">
                <CheckCircle className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                <h3 className="text-lg font-medium text-gray-900 mb-2">Quality Assurance</h3>
                <p className="text-gray-500 mb-4">Monitor and maintain product quality standards</p>
                <Button>Quality Dashboard</Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
