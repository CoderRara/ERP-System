"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Progress } from "@/components/ui/progress"
import {
  Search,
  Filter,
  Plus,
  MoreHorizontal,
  Edit,
  Eye,
  CheckCircle,
  XCircle,
  AlertTriangle,
  BarChart3,
  FileText,
  Award,
  TrendingUp,
  Calendar,
} from "lucide-react"

export default function QualityPage() {
  const [searchTerm, setSearchTerm] = useState("")

  const qualityChecks = [
    {
      id: "QC-001",
      productName: "Wireless Headphones",
      batchNumber: "WH-2024-001",
      checkDate: "2024-01-15",
      inspector: "Sarah Johnson",
      status: "Passed",
      score: 95,
      defects: 0,
      notes: "All quality parameters met",
    },
    {
      id: "QC-002",
      productName: "Laptop Stand",
      batchNumber: "LS-2024-002",
      checkDate: "2024-01-14",
      inspector: "Mike Davis",
      status: "Failed",
      score: 72,
      defects: 3,
      notes: "Surface finish issues detected",
    },
    {
      id: "QC-003",
      productName: "USB-C Cable",
      batchNumber: "UC-2024-003",
      checkDate: "2024-01-13",
      inspector: "Lisa Wilson",
      status: "Passed",
      score: 88,
      defects: 1,
      notes: "Minor packaging defect",
    },
    {
      id: "QC-004",
      productName: "Bluetooth Speaker",
      batchNumber: "BS-2024-004",
      checkDate: "2024-01-12",
      inspector: "John Smith",
      status: "Under Review",
      score: 85,
      defects: 2,
      notes: "Pending final approval",
    },
  ]

  const qualityMetrics = {
    totalChecks: qualityChecks.length,
    passedChecks: qualityChecks.filter((q) => q.status === "Passed").length,
    failedChecks: qualityChecks.filter((q) => q.status === "Failed").length,
    averageScore: Math.round(qualityChecks.reduce((sum, q) => sum + q.score, 0) / qualityChecks.length),
    totalDefects: qualityChecks.reduce((sum, q) => sum + q.defects, 0),
  }

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "Passed":
        return <Badge className="bg-green-600 hover:bg-green-700">Passed</Badge>
      case "Failed":
        return <Badge variant="destructive">Failed</Badge>
      case "Under Review":
        return <Badge variant="secondary">Under Review</Badge>
      default:
        return <Badge variant="outline">{status}</Badge>
    }
  }

  const getScoreColor = (score: number) => {
    if (score >= 90) return "text-green-600"
    if (score >= 80) return "text-yellow-600"
    return "text-red-600"
  }

  const filteredChecks = qualityChecks.filter(
    (check) =>
      check.productName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      check.batchNumber.toLowerCase().includes(searchTerm.toLowerCase()) ||
      check.inspector.toLowerCase().includes(searchTerm.toLowerCase()),
  )

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold">Quality Management</h1>
        <div className="flex gap-2">
          <Button variant="outline">
            <Filter className="h-4 w-4 mr-2" />
            Filter
          </Button>
          <Button>
            <Plus className="h-4 w-4 mr-2" />
            New Quality Check
          </Button>
        </div>
      </div>

      {/* Quality Metrics */}
      <div className="grid gap-4 md:grid-cols-5">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Checks</CardTitle>
            <FileText className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{qualityMetrics.totalChecks}</div>
            <p className="text-xs text-muted-foreground">This month</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Passed</CardTitle>
            <CheckCircle className="h-4 w-4 text-green-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">{qualityMetrics.passedChecks}</div>
            <p className="text-xs text-muted-foreground">
              {Math.round((qualityMetrics.passedChecks / qualityMetrics.totalChecks) * 100)}% pass rate
            </p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Failed</CardTitle>
            <XCircle className="h-4 w-4 text-red-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-red-600">{qualityMetrics.failedChecks}</div>
            <p className="text-xs text-muted-foreground">Need attention</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Avg Score</CardTitle>
            <Award className="h-4 w-4 text-blue-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{qualityMetrics.averageScore}%</div>
            <p className="text-xs text-muted-foreground">Quality score</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Defects</CardTitle>
            <AlertTriangle className="h-4 w-4 text-orange-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-orange-600">{qualityMetrics.totalDefects}</div>
            <p className="text-xs text-muted-foreground">Identified issues</p>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="checks" className="space-y-4">
        <TabsList>
          <TabsTrigger value="checks">Quality Checks</TabsTrigger>
          <TabsTrigger value="standards">Quality Standards</TabsTrigger>
          <TabsTrigger value="audits">Audits</TabsTrigger>
          <TabsTrigger value="reports">Reports</TabsTrigger>
        </TabsList>

        <TabsContent value="checks">
          <Card>
            <CardHeader>
              <div className="flex items-center gap-4">
                <div className="relative flex-1 max-w-md">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                  <Input
                    placeholder="Search quality checks..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-10"
                  />
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Product</TableHead>
                    <TableHead>Batch Number</TableHead>
                    <TableHead>Inspector</TableHead>
                    <TableHead>Date</TableHead>
                    <TableHead>Score</TableHead>
                    <TableHead>Defects</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredChecks.map((check) => (
                    <TableRow key={check.id}>
                      <TableCell>
                        <div>
                          <div className="font-medium">{check.productName}</div>
                          <div className="text-sm text-muted-foreground">{check.id}</div>
                        </div>
                      </TableCell>
                      <TableCell>
                        <Badge variant="outline">{check.batchNumber}</Badge>
                      </TableCell>
                      <TableCell>{check.inspector}</TableCell>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          <Calendar className="h-4 w-4 text-muted-foreground" />
                          {check.checkDate}
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          <span className={`font-medium ${getScoreColor(check.score)}`}>{check.score}%</span>
                          <Progress value={check.score} className="w-16 h-2" />
                        </div>
                      </TableCell>
                      <TableCell>
                        {check.defects > 0 ? (
                          <span className="text-red-600">{check.defects}</span>
                        ) : (
                          <span className="text-green-600">0</span>
                        )}
                      </TableCell>
                      <TableCell>{getStatusBadge(check.status)}</TableCell>
                      <TableCell className="text-right">
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" size="icon">
                              <MoreHorizontal className="h-4 w-4" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuItem>
                              <Eye className="h-4 w-4 mr-2" />
                              View Details
                            </DropdownMenuItem>
                            <DropdownMenuItem>
                              <Edit className="h-4 w-4 mr-2" />
                              Edit Check
                            </DropdownMenuItem>
                            <DropdownMenuItem>
                              <FileText className="h-4 w-4 mr-2" />
                              Generate Report
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="standards">
          <Card>
            <CardHeader>
              <CardTitle>Quality Standards</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-center py-8">
                <Award className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                <h3 className="text-lg font-medium text-gray-900 mb-2">Quality Standards</h3>
                <p className="text-gray-500 mb-4">Define and manage quality standards for your products</p>
                <Button>Create Standard</Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="audits">
          <Card>
            <CardHeader>
              <CardTitle>Quality Audits</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-center py-8">
                <BarChart3 className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                <h3 className="text-lg font-medium text-gray-900 mb-2">Quality Audits</h3>
                <p className="text-gray-500 mb-4">Schedule and manage quality audits</p>
                <Button>Schedule Audit</Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="reports">
          <Card>
            <CardHeader>
              <CardTitle>Quality Reports</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid gap-4 md:grid-cols-3">
                <Card>
                  <CardContent className="pt-6">
                    <div className="text-center">
                      <TrendingUp className="h-8 w-8 text-blue-500 mx-auto mb-2" />
                      <h4 className="font-medium">Quality Trends</h4>
                      <p className="text-sm text-muted-foreground">Quality performance over time</p>
                      <Button className="mt-2" size="sm">
                        Generate
                      </Button>
                    </div>
                  </CardContent>
                </Card>
                <Card>
                  <CardContent className="pt-6">
                    <div className="text-center">
                      <AlertTriangle className="h-8 w-8 text-orange-500 mx-auto mb-2" />
                      <h4 className="font-medium">Defect Analysis</h4>
                      <p className="text-sm text-muted-foreground">Common defects and patterns</p>
                      <Button className="mt-2" size="sm">
                        Generate
                      </Button>
                    </div>
                  </CardContent>
                </Card>
                <Card>
                  <CardContent className="pt-6">
                    <div className="text-center">
                      <Award className="h-8 w-8 text-green-500 mx-auto mb-2" />
                      <h4 className="font-medium">Compliance Report</h4>
                      <p className="text-sm text-muted-foreground">Standards compliance status</p>
                      <Button className="mt-2" size="sm">
                        Generate
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
