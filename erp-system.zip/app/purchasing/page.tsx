"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import {
  Search,
  Filter,
  Plus,
  MoreHorizontal,
  Edit,
  Eye,
  ShoppingCart,
  TrendingUp,
  Calendar,
  FileText,
  Building2,
} from "lucide-react"

export default function PurchasingPage() {
  const [searchTerm, setSearchTerm] = useState("")

  const purchaseOrders = [
    {
      id: "PO-001",
      orderNumber: "PUR-2024-001",
      supplier: "Electronics Wholesale Ltd",
      date: "2024-01-15",
      items: 12,
      subtotal: 15000.0,
      tax: 1500.0,
      total: 16500.0,
      status: "Received",
      paymentStatus: "Paid",
      buyer: "John Smith",
      expectedDate: "2024-01-20",
    },
    {
      id: "PO-002",
      orderNumber: "PUR-2024-002",
      supplier: "Office Furniture Direct",
      date: "2024-01-14",
      items: 8,
      subtotal: 8500.0,
      tax: 850.0,
      total: 9350.0,
      status: "Pending",
      paymentStatus: "Pending",
      buyer: "Sarah Johnson",
      expectedDate: "2024-01-25",
    },
    {
      id: "PO-003",
      orderNumber: "PUR-2024-003",
      supplier: "Tech Components Inc",
      date: "2024-01-13",
      items: 25,
      subtotal: 22000.0,
      tax: 2200.0,
      total: 24200.0,
      status: "Shipped",
      paymentStatus: "Paid",
      buyer: "Mike Davis",
      expectedDate: "2024-01-18",
    },
    {
      id: "PO-004",
      orderNumber: "PUR-2024-004",
      supplier: "Global Accessories Co",
      date: "2024-01-12",
      items: 6,
      subtotal: 3200.0,
      tax: 320.0,
      total: 3520.0,
      status: "Draft",
      paymentStatus: "Unpaid",
      buyer: "Lisa Wilson",
      expectedDate: "2024-01-22",
    },
  ]

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "Received":
        return <Badge className="bg-green-600 hover:bg-green-700">Received</Badge>
      case "Shipped":
        return <Badge variant="default">Shipped</Badge>
      case "Pending":
        return <Badge variant="secondary">Pending</Badge>
      case "Draft":
        return <Badge variant="outline">Draft</Badge>
      default:
        return <Badge variant="outline">{status}</Badge>
    }
  }

  const getPaymentBadge = (status: string) => {
    switch (status) {
      case "Paid":
        return <Badge className="bg-green-600 hover:bg-green-700">Paid</Badge>
      case "Pending":
        return <Badge variant="secondary">Pending</Badge>
      case "Unpaid":
        return <Badge variant="destructive">Unpaid</Badge>
      default:
        return <Badge variant="outline">{status}</Badge>
    }
  }

  const filteredOrders = purchaseOrders.filter(
    (order) =>
      order.orderNumber.toLowerCase().includes(searchTerm.toLowerCase()) ||
      order.supplier.toLowerCase().includes(searchTerm.toLowerCase()) ||
      order.buyer.toLowerCase().includes(searchTerm.toLowerCase()),
  )

  const totalOrders = purchaseOrders.length
  const totalSpent = purchaseOrders.reduce((sum, order) => sum + order.total, 0)
  const receivedOrders = purchaseOrders.filter((order) => order.status === "Received").length
  const avgOrderValue = totalSpent / totalOrders

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold text-gray-900">Purchase Management</h1>
        <div className="flex gap-2">
          <Button variant="outline">
            <Filter className="h-4 w-4 mr-2" />
            Filter
          </Button>
          <Button>
            <Plus className="h-4 w-4 mr-2" />
            New Purchase Order
          </Button>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid gap-4 md:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Orders</CardTitle>
            <ShoppingCart className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{totalOrders}</div>
            <div className="flex items-center text-xs text-green-500">
              <TrendingUp className="mr-1 h-3 w-3" />
              +15% from last month
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Spent</CardTitle>
            <Building2 className="h-4 w-4 text-red-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">${totalSpent.toLocaleString()}</div>
            <div className="flex items-center text-xs text-red-500">
              <TrendingUp className="mr-1 h-3 w-3" />
              +22% from last month
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Received Orders</CardTitle>
            <Badge className="bg-green-600">{receivedOrders}</Badge>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{receivedOrders}</div>
            <div className="text-xs text-gray-500">
              {Math.round((receivedOrders / totalOrders) * 100)}% completion rate
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Avg Order Value</CardTitle>
            <TrendingUp className="h-4 w-4 text-blue-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">${Math.round(avgOrderValue).toLocaleString()}</div>
            <div className="flex items-center text-xs text-green-500">
              <TrendingUp className="mr-1 h-3 w-3" />
              +5.3% from last month
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Purchase Orders Table */}
      <Card>
        <CardHeader>
          <div className="flex items-center gap-4">
            <div className="relative flex-1 max-w-md">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
              <Input
                placeholder="Search purchase orders..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Order</TableHead>
                <TableHead>Supplier</TableHead>
                <TableHead>Date</TableHead>
                <TableHead>Items</TableHead>
                <TableHead>Total</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Payment</TableHead>
                <TableHead>Expected</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredOrders.map((order) => (
                <TableRow key={order.id}>
                  <TableCell>
                    <div>
                      <div className="font-medium">{order.orderNumber}</div>
                      <div className="text-sm text-muted-foreground">{order.id}</div>
                    </div>
                  </TableCell>
                  <TableCell className="font-medium">{order.supplier}</TableCell>
                  <TableCell>
                    <div className="flex items-center gap-2">
                      <Calendar className="h-4 w-4 text-muted-foreground" />
                      {order.date}
                    </div>
                  </TableCell>
                  <TableCell>{order.items} items</TableCell>
                  <TableCell>
                    <div>
                      <div className="font-medium">${order.total.toLocaleString()}</div>
                      <div className="text-sm text-muted-foreground">Tax: ${order.tax.toLocaleString()}</div>
                    </div>
                  </TableCell>
                  <TableCell>{getStatusBadge(order.status)}</TableCell>
                  <TableCell>{getPaymentBadge(order.paymentStatus)}</TableCell>
                  <TableCell>{order.expectedDate}</TableCell>
                  <TableCell className="text-right">
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" size="icon">
                          <MoreHorizontal className="h-4 w-4" />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end">
                        <DropdownMenuItem>
                          <Eye className="h-4 w-4 mr-2" />
                          View Details
                        </DropdownMenuItem>
                        <DropdownMenuItem>
                          <Edit className="h-4 w-4 mr-2" />
                          Edit Order
                        </DropdownMenuItem>
                        <DropdownMenuItem>
                          <FileText className="h-4 w-4 mr-2" />
                          Generate Report
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  )
}
