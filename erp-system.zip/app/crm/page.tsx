"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  Search,
  Filter,
  Plus,
  MoreHorizontal,
  Edit,
  Eye,
  Users,
  Calendar,
  Phone,
  Mail,
  DollarSign,
  TrendingUp,
  Target,
  UserCheck,
  Star,
} from "lucide-react"

export default function CRMPage() {
  const [searchTerm, setSearchTerm] = useState("")

  const leads = [
    {
      id: "LEAD-001",
      name: "Acme Corporation",
      contact: "John Doe",
      email: "john.doe@acme.com",
      phone: "+1 (555) 123-4567",
      source: "Website",
      value: 50000,
      stage: "Qualified",
      probability: 75,
      assignedTo: "Sarah Johnson",
      lastContact: "2024-01-15",
    },
    {
      id: "LEAD-002",
      name: "Tech Innovations Ltd",
      contact: "Jane Smith",
      email: "jane.smith@techinnovations.com",
      phone: "+1 (555) 234-5678",
      source: "Referral",
      value: 75000,
      stage: "Proposal",
      probability: 60,
      assignedTo: "Mike Davis",
      lastContact: "2024-01-14",
    },
    {
      id: "LEAD-003",
      name: "Global Solutions Inc",
      contact: "Bob Wilson",
      email: "bob.wilson@globalsolutions.com",
      phone: "+1 (555) 345-6789",
      source: "Cold Call",
      value: 25000,
      stage: "Negotiation",
      probability: 85,
      assignedTo: "Lisa Wilson",
      lastContact: "2024-01-13",
    },
    {
      id: "LEAD-004",
      name: "Future Systems Co",
      contact: "Alice Brown",
      email: "alice.brown@futuresystems.com",
      phone: "+1 (555) 456-7890",
      source: "Trade Show",
      value: 100000,
      stage: "Closed Won",
      probability: 100,
      assignedTo: "John Smith",
      lastContact: "2024-01-12",
    },
  ]

  const opportunities = [
    {
      id: "OPP-001",
      name: "Enterprise Software License",
      account: "Acme Corporation",
      value: 150000,
      stage: "Proposal",
      probability: 70,
      closeDate: "2024-02-15",
      owner: "Sarah Johnson",
    },
    {
      id: "OPP-002",
      name: "Hardware Upgrade Project",
      account: "Tech Innovations Ltd",
      value: 85000,
      stage: "Negotiation",
      probability: 80,
      closeDate: "2024-02-28",
      owner: "Mike Davis",
    },
    {
      id: "OPP-003",
      name: "Consulting Services",
      account: "Global Solutions Inc",
      value: 45000,
      stage: "Qualified",
      probability: 50,
      closeDate: "2024-03-15",
      owner: "Lisa Wilson",
    },
  ]

  const activities = [
    {
      id: "ACT-001",
      type: "Call",
      subject: "Follow-up call with Acme Corp",
      contact: "John Doe",
      date: "2024-01-16",
      time: "10:00 AM",
      status: "Scheduled",
      assignedTo: "Sarah Johnson",
    },
    {
      id: "ACT-002",
      type: "Meeting",
      subject: "Product demo for Tech Innovations",
      contact: "Jane Smith",
      date: "2024-01-17",
      time: "2:00 PM",
      status: "Scheduled",
      assignedTo: "Mike Davis",
    },
    {
      id: "ACT-003",
      type: "Email",
      subject: "Proposal sent to Global Solutions",
      contact: "Bob Wilson",
      date: "2024-01-15",
      time: "3:30 PM",
      status: "Completed",
      assignedTo: "Lisa Wilson",
    },
  ]

  const getStageBadge = (stage: string) => {
    switch (stage) {
      case "Qualified":
        return <Badge variant="secondary">Qualified</Badge>
      case "Proposal":
        return <Badge variant="outline">Proposal</Badge>
      case "Negotiation":
        return <Badge className="bg-orange-600 hover:bg-orange-700">Negotiation</Badge>
      case "Closed Won":
        return <Badge className="bg-green-600 hover:bg-green-700">Closed Won</Badge>
      case "Closed Lost":
        return <Badge variant="destructive">Closed Lost</Badge>
      default:
        return <Badge variant="outline">{stage}</Badge>
    }
  }

  const getActivityStatusBadge = (status: string) => {
    switch (status) {
      case "Completed":
        return <Badge className="bg-green-600 hover:bg-green-700">Completed</Badge>
      case "Scheduled":
        return <Badge variant="default">Scheduled</Badge>
      case "Overdue":
        return <Badge variant="destructive">Overdue</Badge>
      default:
        return <Badge variant="outline">{status}</Badge>
    }
  }

  const filteredLeads = leads.filter(
    (lead) =>
      lead.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      lead.contact.toLowerCase().includes(searchTerm.toLowerCase()) ||
      lead.email.toLowerCase().includes(searchTerm.toLowerCase()),
  )

  const totalLeads = leads.length
  const qualifiedLeads = leads.filter((l) => l.stage === "Qualified" || l.stage === "Proposal").length
  const totalValue = leads.reduce((sum, l) => sum + l.value, 0)
  const avgDealSize = totalValue / totalLeads

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold text-gray-900">Customer Relationship Management</h1>
        <div className="flex gap-2">
          <Button variant="outline">
            <Filter className="h-4 w-4 mr-2" />
            Filter
          </Button>
          <Button>
            <Plus className="h-4 w-4 mr-2" />
            Add Lead
          </Button>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid gap-4 md:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Leads</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{totalLeads}</div>
            <div className="flex items-center text-xs text-green-500">
              <TrendingUp className="mr-1 h-3 w-3" />
              +12% from last month
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Qualified Leads</CardTitle>
            <Target className="h-4 w-4 text-green-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-500">{qualifiedLeads}</div>
            <div className="text-xs text-gray-500">{Math.round((qualifiedLeads / totalLeads) * 100)}% conversion</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Pipeline Value</CardTitle>
            <DollarSign className="h-4 w-4 text-blue-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">${(totalValue / 1000).toFixed(0)}K</div>
            <div className="text-xs text-gray-500">Total opportunity value</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Avg Deal Size</CardTitle>
            <Star className="h-4 w-4 text-purple-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">${(avgDealSize / 1000).toFixed(0)}K</div>
            <div className="text-xs text-gray-500">Per opportunity</div>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="leads" className="space-y-4">
        <TabsList>
          <TabsTrigger value="leads">Leads</TabsTrigger>
          <TabsTrigger value="opportunities">Opportunities</TabsTrigger>
          <TabsTrigger value="activities">Activities</TabsTrigger>
          <TabsTrigger value="reports">Reports</TabsTrigger>
        </TabsList>

        <TabsContent value="leads">
          <Card>
            <CardHeader>
              <div className="flex items-center gap-4">
                <div className="relative flex-1 max-w-md">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                  <Input
                    placeholder="Search leads..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-10"
                  />
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Lead</TableHead>
                    <TableHead>Contact</TableHead>
                    <TableHead>Source</TableHead>
                    <TableHead>Value</TableHead>
                    <TableHead>Stage</TableHead>
                    <TableHead>Probability</TableHead>
                    <TableHead>Assigned To</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredLeads.map((lead) => (
                    <TableRow key={lead.id}>
                      <TableCell>
                        <div>
                          <div className="font-medium">{lead.name}</div>
                          <div className="text-sm text-muted-foreground">{lead.id}</div>
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="space-y-1">
                          <div className="font-medium">{lead.contact}</div>
                          <div className="flex items-center gap-2 text-sm text-muted-foreground">
                            <Mail className="h-3 w-3" />
                            {lead.email}
                          </div>
                          <div className="flex items-center gap-2 text-sm text-muted-foreground">
                            <Phone className="h-3 w-3" />
                            {lead.phone}
                          </div>
                        </div>
                      </TableCell>
                      <TableCell>
                        <Badge variant="outline">{lead.source}</Badge>
                      </TableCell>
                      <TableCell>${lead.value.toLocaleString()}</TableCell>
                      <TableCell>{getStageBadge(lead.stage)}</TableCell>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          <div className="w-16 bg-gray-200 rounded-full h-2">
                            <div className="h-2 rounded-full bg-blue-500" style={{ width: `${lead.probability}%` }} />
                          </div>
                          <span className="text-sm">{lead.probability}%</span>
                        </div>
                      </TableCell>
                      <TableCell>{lead.assignedTo}</TableCell>
                      <TableCell className="text-right">
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" size="icon">
                              <MoreHorizontal className="h-4 w-4" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuItem>
                              <Eye className="h-4 w-4 mr-2" />
                              View Details
                            </DropdownMenuItem>
                            <DropdownMenuItem>
                              <Edit className="h-4 w-4 mr-2" />
                              Edit Lead
                            </DropdownMenuItem>
                            <DropdownMenuItem>
                              <UserCheck className="h-4 w-4 mr-2" />
                              Convert to Customer
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="opportunities">
          <Card>
            <CardHeader>
              <CardTitle>Sales Opportunities</CardTitle>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Opportunity</TableHead>
                    <TableHead>Account</TableHead>
                    <TableHead>Value</TableHead>
                    <TableHead>Stage</TableHead>
                    <TableHead>Probability</TableHead>
                    <TableHead>Close Date</TableHead>
                    <TableHead>Owner</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {opportunities.map((opp) => (
                    <TableRow key={opp.id}>
                      <TableCell>
                        <div>
                          <div className="font-medium">{opp.name}</div>
                          <div className="text-sm text-muted-foreground">{opp.id}</div>
                        </div>
                      </TableCell>
                      <TableCell className="font-medium">{opp.account}</TableCell>
                      <TableCell>${opp.value.toLocaleString()}</TableCell>
                      <TableCell>{getStageBadge(opp.stage)}</TableCell>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          <div className="w-16 bg-gray-200 rounded-full h-2">
                            <div className="h-2 rounded-full bg-green-500" style={{ width: `${opp.probability}%` }} />
                          </div>
                          <span className="text-sm">{opp.probability}%</span>
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          <Calendar className="h-4 w-4 text-muted-foreground" />
                          {opp.closeDate}
                        </div>
                      </TableCell>
                      <TableCell>{opp.owner}</TableCell>
                      <TableCell className="text-right">
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" size="icon">
                              <MoreHorizontal className="h-4 w-4" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuItem>
                              <Eye className="h-4 w-4 mr-2" />
                              View Details
                            </DropdownMenuItem>
                            <DropdownMenuItem>
                              <Edit className="h-4 w-4 mr-2" />
                              Edit Opportunity
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="activities">
          <Card>
            <CardHeader>
              <CardTitle>Activities & Tasks</CardTitle>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Type</TableHead>
                    <TableHead>Subject</TableHead>
                    <TableHead>Contact</TableHead>
                    <TableHead>Date & Time</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Assigned To</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {activities.map((activity) => (
                    <TableRow key={activity.id}>
                      <TableCell>
                        <Badge variant="outline">{activity.type}</Badge>
                      </TableCell>
                      <TableCell className="font-medium">{activity.subject}</TableCell>
                      <TableCell>{activity.contact}</TableCell>
                      <TableCell>
                        <div className="space-y-1">
                          <div className="flex items-center gap-2 text-sm">
                            <Calendar className="h-3 w-3" />
                            {activity.date}
                          </div>
                          <div className="text-sm text-muted-foreground">{activity.time}</div>
                        </div>
                      </TableCell>
                      <TableCell>{getActivityStatusBadge(activity.status)}</TableCell>
                      <TableCell>{activity.assignedTo}</TableCell>
                      <TableCell className="text-right">
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" size="icon">
                              <MoreHorizontal className="h-4 w-4" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuItem>
                              <Eye className="h-4 w-4 mr-2" />
                              View Details
                            </DropdownMenuItem>
                            <DropdownMenuItem>
                              <Edit className="h-4 w-4 mr-2" />
                              Edit Activity
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="reports">
          <Card>
            <CardHeader>
              <CardTitle>CRM Reports & Analytics</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-center py-8">
                <Target className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                <h3 className="text-lg font-medium text-gray-900 mb-2">Sales Analytics</h3>
                <p className="text-gray-500 mb-4">Generate detailed reports on sales performance and pipeline</p>
                <Button>Generate Reports</Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
